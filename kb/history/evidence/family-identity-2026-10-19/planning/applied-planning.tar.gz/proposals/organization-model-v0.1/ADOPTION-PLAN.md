> Current application status: see [CURRENT-STATE.md](CURRENT-STATE.md). Historical review wording below is retained; UTB-DEC-005 and the application record govern the approved batch.

# Odisha Blueprint — adoption sequence

**UTP-GOV-013 · Planning record v0.4 · 27 September 2026**

## Founder-directed order

> To start with we will adopt the blueprint in Utkal Project and then Utkal Collective and Utkal Unbound - BAL and BAC we will start later

Source: Founder’s message in this planning conversation, recorded 27 September 2026. This settles the adoption order. Detailed operating documents remain subject to the existing review-before-application direction; intent to adopt is recorded separately from an approved version or completed adoption.

| Order | Project | Current adoption position | Focus |
|---|---|---|---|
| 1 | UTP · Utkal Project | First adoption target; preparation next | Establish and exercise the complete common structure in the master project and its own knowledge work |
| 2 | ODC · Odisha Collective | Queued after UTP | Apply the same structure to an independently governed commercial/community initiative |
| 3 | ODU · Odisha Unbound | Queued after ODC | Define its own charter and apply the tested structure; exact mission and placement remain open |
| Later | BAL · Bhubaneswar Alpha Lab | Deferred; no start date | Retain the concept; no current implementation or staffing work |
| Later | BAC · Bhubaneswar Athletic Club | Deferred; no start date | Retain the concept; no current implementation or staffing work |

The ordering of BAL versus BAC is not decided. Neither deferred initiative blocks UTP, ODC or ODU. Deferral does not mean cancellation or that an operating programme has been paused. External member rollout and managed services remain future proposals with no launch date.

## Parallel Blueprint development

The Founder has separately directed that ODB itself be built. [ODB’s build plan](../../subprojects/utkal-blueprint/README.md) owns generic templates, typed identity, validators and release preparation. This UTP plan owns the first local instance and real-work pilot. The two workstreams exchange reviewed candidates and evidence; they do not share a single completion status. ODB development adds no new adopter before UTP and does not reactivate BAL or BAC.

## UTP first: proposed adoption deliverables

Prepare one concrete UTP instance for the Founder’s review:

1. Charter covering the master coordination role and UTP’s own knowledge mission, with explicit boundaries between those responsibilities.
2. Organization and reporting records showing the Founder as the only appointed human, future roles as unfilled, and human supervision of any proposed AI assignment.
3. UTP-specific team/JDs and working agreement using the common structure; approved persona names do not automatically activate their assignments.
4. Work, review, decision and lifecycle records, with the exact Blueprint version and each record’s honest approval state.
5. A bounded practice assignment and evidence requirements, such as a reviewed knowledge contribution. The exact assignment remains to be selected.
6. An exact application plan identifying destination files, any canonical OKF/PRD changes and permissions or workflow changes. Preserve existing baselines and obtain the applicable human decision before applying it.

The review should distinguish adopting documentation, activating a role, running a practice assignment and installing any tooling. A single explicit approval can cover a concrete bounded batch; it does not need a separate question for each routine action.

## Learning before expansion

Recommended readiness evidence before moving to ODC: UTP’s own governing documents are approved; one bounded workflow has been completed with traceable human decisions; shortcomings have been recorded; and the reusable parts can be separated from UTP-specific content. These are proposed progression criteria, not a new automatic gate or measured result.

ODC then gets its own charter, human accountability, team, work records and version-adoption decision. Incorporate useful UTP lessons without copying UTP’s editorial mission or assuming commercial authority. ODU follows with its own reviewed purpose and placement; adoption order does not settle its organizational parent or make it a legal subsidiary.

The Founder decides when to progress. Each project retains an independent lifecycle and may adopt a later reviewed Blueprint version. An update in UTP does not silently modify ODC or ODU.

## Deferred initiatives and training

Keep BAL and BAC in the portfolio registry as deferred concepts. Do not prepare their operating launch, appoint staff, activate AI assignments or make them dependencies of the initial rollout. BAL’s possible future involvement in training remains an option for later; initial Blueprint learning must use actually available human capacity.

## Evidence of adoption

For each project record separately: planned position, reviewed package/version, actual human adoption decision, applied artifacts, any activated assignments and verification evidence. Keep `template_version_adopted` unset until an actual version-specific adoption is recorded. Current state is a confirmed sequence with adoption not yet completed.
