# Current applied state

The Founder approved final setup package review v0.2 with **“The next batch is approved”**, recorded as **ODB-DEC-005**. Both repositories remain private.

The reviewed initial documents, role/JD standard, UTP charter and assignments are applied. **Anvesha Acharya** and **Drishti Senapati** are confirmed alongside **Disha Dash** and **Samanta Chandrasekhar**. **Ahimanikya Satapathy** retains final internal authority. No human reports to an AI.

UTP adopts Blueprint **0.1.0-rc.1**, immutable commit `ab5cd05315feecbc5d5c71b372d198c67ee29910`. There is no automatic adoption by ODC, ODU, BAL or BAC and no claim of runtime enforcement.

The AI assignments are bounded role passes by the current assistant in this conversation. The first draft and local preview await the Founder's review. No independent agents or public website were launched.

This state record supersedes stale pending/activation wording in the historical local proposal files. It does not approve unrelated proposals. The exact reviewed archive remains preserved.

See [application result](../../releases/initial-baseline-v0.1/APPLICATION-RESULT.json), [entry](../../implementation/utp-preview/ENTRY.md) and [review](../../implementation/utp-preview/REVIEW.md).
