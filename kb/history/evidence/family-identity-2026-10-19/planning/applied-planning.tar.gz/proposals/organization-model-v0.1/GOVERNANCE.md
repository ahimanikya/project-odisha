# Governance, decisions and project lifecycle

**UTP-GOV-009 · Draft v0.3 · For review**

This matrix describes internal Utkal governance. For an external organization adopting Odisha Blueprint, its own authorized human governs its local decisions; the Founder governs Utkal’s provider-side commitments. [Central governance](CENTRAL-GOVERNANCE.md) specifies service scope and the two separate approval domains.

## Decision rights

| Decision | AI/AP contribution | Human authority now |
|---|---|---|
| Mission, charter, project relationships or closure | Draft options, dependencies and impact | Founder decides |
| Team appointment, personal JD, access or delegation | Prepare proposal and access scope | Founder decides; no automatic appointment |
| Work inside an authorized brief | Research, draft, implement and check within granted scope | Founder’s existing authorization governs; no repeated permission for routine steps |
| Evidence or quality assessment | Report findings and limits honestly | Named human assesses decisions requiring human expertise; Founder decides release, not what the evidence says |
| Budget, membership fees, outside commitments | Prepare concrete proposal | Founder approves exact commitment; affected external parties consent separately |
| Canonical adoption, publication, merge or deployment | Prepare reviewable result and execution plan | Founder’s authorization must cover the action and revision |
| Cross-project work or data access | Identify both project scopes and effects | Founder authorizes each affected scope; one project’s permission does not grant another’s |
| Template update | Prepare versioned differences and migration impact | Founder approves template release and each project’s adoption |

A human may approve a fully prepared bounded batch. Routine execution within that decision can proceed without repeated questions. Material changes to the candidate, scope, cost, access or external effects return for a new decision. When the Founder is unavailable, affected decisions wait; unrelated authorized work may continue.

## Independent lifecycle

Proposed project states are **idea → definition → authorized pilot → operating → paused → closed**. These are labels, not automatic transitions. Paused work can resume to its recorded prior state after an authorized decision. A rejected or abandoned idea can close directly. A project can also remain in definition while research continues.

For every transition record project code, from/to state, reason, actual human decision reference, effective date, affected scope and outstanding obligations. State changes do not create permissions. An operating project still needs the relevant authorization for a new external commitment or release.

Current honest position: UTP has active planning and knowledge preparation, but no website launch is claimed; ODC has planning documents; ODU, BAC and BAL are concepts. None of those descriptions claims that the new governance model is adopted.

## Gates scaled to work

1. **Define:** identify the project, need, accountable human, deliverable, acceptance evidence and dependencies.
2. **Authorize scope:** trace the actual instruction or approved brief. The current instruction already authorizes preparing this model.
3. **Prepare and review:** produce the concrete result, record contributors and checks, disclose unfinished work and review independence.
4. **Human decision:** present the exact revision and proposed action, including effects on other projects. Approval of a concept is distinct from deployment or spending authority.
5. **Execute and verify:** perform only authorized actions and record results; never equate “approved” with “applied” or “tested.”
6. **Learn:** propose improvements; adopt them per project through a versioned decision.

These gates apply to different work types with suitable evidence. A training camp needs a human delivery owner and a programme plan; a software release needs technical validation; knowledge publication needs editorial/source checks. The shared template does not impose software tests on every activity.

## Approval record

Record project-prefixed decision ID, human identity, real instruction/message reference (or dated exact quotation if no stable reference exists), action, artifact version/digest, scope, limits, conditions, date and status. An AI can transcribe approval, but its transcription is not the source of authority. Silence, an AI PASS, a favourable test, access credentials or a prefilled approval field never create authorization.

A changed candidate must be compared with the approved version. Existing authorization remains sufficient for corrections explicitly within its scope; consequential differences require a new decision. Do not claim technical enforcement until access controls and workflow checks are actually implemented and tested.

## Escalation and closure

Pause an affected action when authority is unclear or a material problem is discovered; explain the exact issue and offer a concrete resolution. Do not hide findings, fabricate a human response or stop unrelated authorized preparation. Founder-approved risk acceptance is recorded separately from the finding.

Closing a project requires a plan for open obligations, data and records, contributors, access and dependent projects. Closure does not erase attribution or silently transfer responsibilities to another project.
