# Organization hierarchy and reporting structure

**UTP-GOV-010 · Draft v0.3 · 27 September 2026 · For review**

The Founder explicitly added: “There is Org Hierarchy and reporting structure too”. Both are required parts of the common organizational template. The arrangements below distinguish confirmed project relationships from proposed human positions and reporting rules. A diagram does not appoint a person, activate an agent or delegate authority.

This chart describes the internal Utkal organization. An independent member using **Odisha Blueprint** maintains its own hierarchy and human reporting lines. Its association with a Blueprint service provider is a service relationship, not an automatic reporting line into Utkal. Any agreed human management role must be separately documented.

**Mandatory human-reporting rule:** [ODB-GOV-001](HUMAN-AUTHORITY.md) records the Founder’s explicit direction: humans never report to AI. All human reporting lines remain human; AI assignments have named human supervisors. No local exception, temporary arrangement or delegated authority may reverse this relationship.

## Four distinct relationships

| Relationship | What it answers | What it does not grant |
|---|---|---|
| Organization/project hierarchy | Where does the project sit and how does it relate to the master? | Legal ownership, access to all child-project data or automatic control of its decisions |
| Human reporting line | Which human provides direction, resolves priorities and receives accountability for this role? | Powers outside that manager’s explicitly authorized remit |
| AI supervision and task reporting | Which named human owns this AI assignment, reviews its output and can stop it? | Authority over humans or the right to become an approver |
| Collaboration or functional advice | Who contributes expertise or coordinates a bounded piece of work? | A second manager, permission to change priorities unilaterally or a final gate |

## Organization hierarchy

```mermaid
flowchart TD
  UTP["UTP · Utkal Project · master and own mission"] --> ODC["UTC · Utkal Collective"]
  ODC --> BAC["BAC · Bhubaneswar Athletic Club"]
  ODC --> BAL["BAL · Bhubaneswar Alpha Lab"]
  UTP -.->|"placement to confirm"| ODU["UTU · Utkal Unbound"]
```

ODC remains independent and closely associated with UTP. These are organizational coordination links, not a declaration of legal subsidiaries. BAC and BAL remain projects with their own charters, teams and lifecycles within their intended ODC relationship. ODU’s precise placement remains open. Farm-resort development is a ODC concept until a specific project is defined.

Every level uses the same structural model. Parent-level reporting summarizes outcomes, dependencies, resources and decisions needed; it does not silently replace the child charter or collapse its lifecycle into the parent’s.

## Current human structure

**Ahimanikya is the only appointed human and retains final authority.** He presently holds the accountability for UTP, ODC, ODU, BAC and BAL. Founder & Editor-in-Chief remains his established UTP title. Holding several responsibilities does not create several people or a self-reporting chain.

There are no appointed project leads, coaches, mentors, additional Editors or managers. The current assistant is preparing this model under the Founder’s direction. Disha, Anvesha, Samanta and Drishti are approved persona names with draft role profiles; they are not active managers or four independently running agents.

## Proposed human reporting structure as people join

```mermaid
flowchart TD
  F["Ahimanikya · Founder · final authority"] --> UPL["UTP human project lead · future assignment"]
  F --> UCL["UTC human project lead · future assignment"]
  F -.->|"interim route proposed; placement open"| UUL["UTU human project lead · future assignment"]
  UCL --> BACL["BAC human project lead · future assignment"]
  UCL --> BALL["BAL human project lead · future assignment"]
  UPL --> UPT["UTP human contributors / Editors"]
  UCL --> UCT["UTC human contributors / operators"]
  UUL --> UUT["UTU human contributors"]
  BACL --> BACT["BAC human contributors / coaches"]
  BALL --> BALT["BAL human contributors / mentors"]
```

All positions other than the Founder are proposed, unfilled responsibilities. “Project lead” is a structural role; the local JD can specify an appropriate title. The Founder can continue holding an unfilled responsibility without creating a new appointment. A BAC or BAL lead would report directly to the Founder until a ODC human lead is appointed with an explicit supervisory remit.

Each human assignment has one named primary human manager. Reporting lines must be acyclic. A manager controls only the work, resources or personnel decisions explicitly delegated to them. Final Founder-reserved approvals remain with him even when routine management is delegated. A new reporting line does not itself approve that delegation.

The same individual can hold roles in several projects. Record each assignment, its scope, capacity and reporting line separately. Resolve conflicting priorities through the relevant human managers and then the Founder; an AI coordinator cannot choose whose authority wins.

## AI supervision

Every activated AI assignment has a named accountable human, a project-scoped JD/brief, allowed tools/data and a route for reporting outputs and blockers. Initially that human is the Founder. If a future human project lead is explicitly given supervisory responsibility, an AI can support and report to that lead within its brief; the Founder’s final gate remains unchanged.

```mermaid
flowchart LR
  A["AI / AP assignment"] -->|"outputs, evidence, uncertainty, blockers"| H["Named human supervisor"]
  H -->|"direction, scope, review, stop"| A
  H -->|"reserved decision or escalation"| F["Founder · final authority"]
```

When the supervisor is the Founder, the last two boxes are one person. AI personas have no human direct reports. Disha’s coordination role, for example, can organize approved work and prepare status summaries; it cannot appoint people, issue managerial judgments or authorize their work outside the human-approved scope. AI-to-AI task handoffs, where separately authorized, are execution arrangements under the same human accountability, not an AI management hierarchy.

The proposed [AI Project Coordinator](AI-PROJECT-COORDINATOR.md) fits this supervision structure. [Disha’s UTP JD](UTP-DISHA-COORDINATOR.md) reports to the Founder; it does not occupy any of the future human project-lead boxes or acquire authority over human contributors.

## Required reporting record in every project

| Field | Required content |
|---|---|
| Project and assignment | Stable project code, role/JD ID, person or AI identity, assignment status |
| Organization placement | Parent/coordinating project; relationship meaning and any unresolved placement |
| Primary human manager or AI supervisor | Named human and appointment/delegation reference; no invented placeholder presented as appointed |
| Authority | Decisions the role may make; Founder-reserved decisions; budget/access limits |
| Functional and task relationships | Advisors, reviewers and bounded task coordinators, explicitly distinguished from line management |
| Accountability | Expected outputs, outcomes, evidence and handover duties |
| Reporting agreement | Recipient, content, channel, agreed cadence and escalation conditions |
| History | Effective date, version, actual approval, changes, end date and replacement/handover |

Use the same fields in all projects; actual people, responsibilities and cadence differ. Private personal or performance records remain outside public Git and public organizational charts.

## Working reports and escalation

Proposed report format: project/work ID, outcome since last report, next step, evidence, blockers, dependencies, costs/capacity implications and exact human decisions needed. Use a short summary at meaningful milestones; agree any recurring cadence per project rather than assuming weekly meetings or scheduling automatic reports.

Routine questions go to the named human manager/supervisor. Reserved decisions and unresolved cross-project conflicts go to the Founder. A concern about the manager, misuse of authority or an unresolved material issue may be raised directly with the Founder; the reporting chain must not prevent escalation. With no appointed manager, report to the Founder.

An AI reports uncertainty and failures honestly and pauses the affected action when necessary. It cannot fabricate a manager’s response, override an unavailable human or approve a stalled item to keep work moving.

## Changes and adoption

Appointments, reporting-line changes and delegations are distinct, versioned human decisions. Update the org chart, team roster, affected JDs, access and handover records together. Preserve earlier relationships and effective dates. Do not automatically propagate an appointment or authority change to other project roles held by the same person.

These are draft organizational controls, not implemented access enforcement. The [common template](PROJECT-TEMPLATE.md) includes this structure for every project; the Founder reviews the exact local appointments and authority before they take effect.
