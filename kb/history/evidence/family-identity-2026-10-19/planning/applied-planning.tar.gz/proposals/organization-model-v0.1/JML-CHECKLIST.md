# Odisha Blueprint — practical JML checklist

**ODB-TPL-004 · v0.1 · 27 September 2026 · Checklist wording approved by Founder**

The Founder has adopted the [Joiner–Mover–Leaver process](JML-LIFECYCLE.md). This checklist is the approved reusable way to record each event. It follows the approved charter, governance and working agreement. Projects fill in their own actual identities, authority, assignments and evidence.

## Join

- Define the project, full member name, human/AI type, JD version, purpose and named human manager or supervisor.
- Specify the bounded first task, expected result, working arrangements, data/tool access and stop conditions.
- Record the authorized human’s actual decision. A reviewed JD or roster entry alone does not activate an assignment.
- For a human, obtain their acknowledgement of the assignment and applicable working agreement. For an AI, verify the loaded brief, project, supervisor and tool boundaries; do not fabricate human acknowledgement.
- Provision only approved access and verify it. If no additional access is needed, record that explicitly.
- Begin the authorized first task and retain its result, checks and human feedback.

**Join complete:** the assignment is authorized, the relevant acknowledgement or configuration checks are recorded, and the approved access is verified. Review of the first task is a separate follow-up outcome.

## Move

- Record the old and proposed new responsibilities, project, supervisor, JD version and reason for change.
- Obtain the applicable human decision and identify its effective point.
- Hand over or explicitly park open work and decisions.
- Record access to **add, remove and retain**, including “none” where applicable; remove obsolete permissions as well as granting new ones.
- Update the assignment and reporting records, verify access and any new orientation, and retain the prior version.

**Move complete:** new responsibilities and permissions match the decision, obsolete access is removed, and open work has an accountable human. A routine session handover within unchanged scope is not a new appointment.

## Leave

- Record the authorized end of the affected assignment and who owns closure.
- Inventory open work and resources; transfer or park them under a named human.
- Stop the relevant execution and remove assignment-specific access, sessions, tokens and scheduled activity as applicable. Access removal need not wait for a perfect handover.
- Verify revocation; record missing verification as an outstanding issue, not completed closure.
- Retain appropriate work history and contribution credit. Handle restricted information under agreed retention and deletion requirements.

**Leave complete:** affected access is verified closed, work is transferred or parked, and remaining obligations have owners. Ending one assignment does not revoke unrelated authorized work.

## Event record to complete

| Field | Entry required |
|---|---|
| Work/event reference | Project-prefixed WORK ID; join, move or leave |
| Member and assignment | Full name, human/AI type, project, JD/version and current/target assignment |
| Human accountability | Actual manager/supervisor and event decision-maker |
| Authority | Actual instruction/decision reference, scope, conditions and effective date |
| Access change | Added, removed and retained access; actual verification evidence |
| Handover | Work, decisions, artifacts, receiving human and unresolved obligations |
| Orientation | Human acknowledgement or AI configuration verification, as applicable |
| Outcome | Proposed, authorized, in progress, verified complete, blocked or cancelled; evidence and next action |

Use safe references instead of credentials or private personal records in public Git. No private data collection begins merely because this template contains an identity field. Event state, member assignment state and project lifecycle remain separate.

**Review decision: approved by Ahimanikya Satapathy.** The Founder replied “Approved - next” after the checklist and first-use proposal were presented. See [the approval record](JML-APPROVAL.md). This approves the checklist wording. Actual member events require their own scoped human decision. No access has been changed and no technical enforcement is claimed.
