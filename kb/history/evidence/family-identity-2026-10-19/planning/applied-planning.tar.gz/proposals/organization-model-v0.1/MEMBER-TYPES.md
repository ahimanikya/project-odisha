# Explicit human and AI member types

**ODB-GOV-002 · Design draft · For review**

Utkal distinguishes identity, role, project assignment and authority. Humans govern; AI personas assist under named human supervision. This document proposes the representation and validation to implement that model.

## Proposed Utkal representation

Use one authoritative identity field: **`kind: human | persona`**. `persona` means AI persona and should display as **AI** to users. If a generated document also needs `human: true/false`, derive it from `kind`; do not maintain two independent values. Unknown or conflicting identity types are validation errors, never silently classified as human.

Keep these concepts separate:

| Record | Fields and purpose |
|---|---|
| Identity | Stable `actor_id`, display name and `kind`; independent of title and project assignment |
| Role profile | JD ID, responsibilities, permitted actor kinds and authority limits |
| Project assignment | Actor ID, project ID, JD/version, named human reporting target, status and actual activation/appointment reference |
| Permission/decision | Explicit human authorization, scope, action and record reference; not inferred from identity type or job title |

Human and AI identities can each have several project-specific responsibilities. Preserve one identity with multiple assignments, rather than creating a second person for a second role. Private contact information stays separate; do not use a public email address as the Blueprint’s required identity key.

### Illustrative assignment data — not an active roster

```json
{
  "actors": [
    { "actor_id": "ahimanikya", "name": "Ahimanikya", "kind": "human" },
    { "actor_id": "disha", "name": "Disha", "kind": "persona" }
  ],
  "assignments": [
    {
      "actor_id": "ahimanikya", "project_id": "UTP", "jd_id": "UTP-JD-001",
      "reports_to": null, "status": "existing_founder",
      "top_accountable_human": true
    },
    {
      "actor_id": "disha", "project_id": "UTP", "jd_id": "UTP-JD-003",
      "reports_to": { "actor_id": "ahimanikya", "project_id": "UTP", "jd_id": "UTP-JD-001" },
      "status": "proposed_not_activated", "activation_decision": null
    }
  ]
}
```

The stable ID spelling and assignment schema above are proposals. The example illustrates identity and reporting, not a loaded runtime configuration. A shared JD may permit only personas, only humans or either kind; the project assignment must identify the actual actor. A Project Manager title never overrides its actor’s kind or authority limits.

## Validation to build into ODB

1. Require an explicit valid `kind`; do not infer it from names, titles, filenames or whether an email exists.
2. Resolve reporting references to actual project assignments and actor records. A non-null target must be a human, authorized for the relevant supervision or management responsibility; cross-project targets need explicit scope.
3. Permit a null reporting target only for an explicitly identified top accountable human. A persona must have a named human supervisor. Reject self-reporting, cycles and an AI anywhere in a human reporting chain.
4. Keep proposed assignments distinct from active ones. Active appointments/AI assignments must have the required real human authorization; a typed record alone is not activation.
5. Reject an assignment whose actor kind is incompatible with its JD, and reject any derived `human` flag that disagrees with `kind`.
6. Enforce [ODB-GOV-001](HUMAN-AUTHORITY.md): humans never report to AI, including temporary or functional reporting. Other authority rules still require explicit human decisions.

These checks are requirements for the Blueprint build. No validator, roster loader or access enforcement has been installed by this note.
