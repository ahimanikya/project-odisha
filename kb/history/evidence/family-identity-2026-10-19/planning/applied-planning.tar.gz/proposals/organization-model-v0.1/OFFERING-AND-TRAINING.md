# Odisha Blueprint — offering and training

**ODB-GOV-012 · Service design draft v0.4 · For review**

## Offering

**Odisha Blueprint: an organization operating model and practical training for human–AI teams.**

Help a participating organization clarify its structure, responsibilities and decisions, then introduce AI assistance into real work under human supervision. Optional ongoing management support follows a defined service scope. The Founder has directed this offering; packaging, delivery ownership, staffing, pricing and launch terms remain proposed.

Initial potential audiences are our own projects, willing hospitality member organizations and founder-led teams. Their needs and willingness to pay have not been established. A hospitality operator, athletic club and incubator can use the same structure while applying different work examples and human expertise.

## Proposed service components

| Component | Work with the organization | Deliverable and acceptance |
|---|---|---|
| Understand and design | Map current work, people, bottlenecks, authority and data boundaries | Human-reviewed baseline and a bounded improvement brief |
| Configure the Blueprint | Write the charter, hierarchy, reporting lines, JDs, working agreement and decision rules | Local human approves the actual documents and assignments |
| Train and practise | Teach staff how to brief, supervise, check and use AI in their roles | Participants demonstrate the relevant skills on a practical exercise |
| Pilot real work | Run one useful workflow with named people and scoped AI assistance | Evidence of completion, human decisions, corrections and handover |
| Sustain and improve | Optional coaching, reviews, updates and authorized operating support | Agreed reports, service scope, exit provisions and evaluated outcomes |

Each component can be scoped separately. A template download is not a managed service; attendance is not evidence of organizational adoption. The service must identify the provider and member-side accountable humans before any real operations begin.

## Training design

| Module | Who it serves | Exercise and observable learning outcome |
|---|---|---|
| Human leadership and AI boundaries | Owners, managers and all participants | Identify the human decision-maker and actions an AI must not self-authorize |
| Organization and roles | Leaders and role holders | Build a small org chart, reporting record and JD with unambiguous authority |
| Briefing an AI co-worker | People doing the work | Write a bounded brief with inputs, output, constraints and acceptance criteria |
| Evidence and review | Contributors and reviewers | Find unsupported claims or errors in a sample output and record corrections |
| Data and access | Anyone using organizational data | Choose permissible inputs and recipients using a realistic scenario with synthetic data |
| Delivery and escalation | Project leads and teams | Carry a task from brief through review and human decision; escalate a changed scope |
| Independent operation | Local owners and nominated maintainers | Update a role or process through the decision record without relying on the instructor |

Training should fit participants’ roles, language needs, starting skills and available time. Delivery duration, cohort size, language options, facilitators and assessment thresholds remain to be designed. Practical sessions require actual human trainers and supervisors; AI can help prepare material and exercises. No trainer has been appointed and no accreditation or certification is claimed.

Use synthetic or explicitly permitted data for exercises. An observed completion statement can describe the exercise and assessor, but must not imply official certification, employment qualification or guaranteed business results.

## A proposed first pilot

Follow the confirmed adoption order **UTP → ODC → ODU**. Start internally in UTP with one small team and a bounded workflow, such as a reviewed knowledge contribution; then apply the lessons in ODC and ODU. BAL and BAC are deferred and are not initial pilot dependencies. A later member pilot could use a hospitality enquiry-and-response workflow with sample data, bringing together role clarity, human approval and AI-assisted drafting.

Before the pilot, record the baseline, intended outcome, time/cost budget, participant consent, named instructor and accountable human. Afterward compare completion time, rework, evidence quality, decision clarity, participant ability to repeat the process and human workload. Include tool/training overhead and any failures. Do not attribute changes to the Blueprint without considering other explanations.

## Acceptance of the service model

- A participant can explain who decides, who reports to whom and which decisions remain with a human.
- Each AI assignment has a named human supervisor and demonstrably bounded inputs/actions.
- One complete workflow has traceable evidence and actual human decisions; failures and corrections remain visible.
- The local owner can maintain the records and continue work without the service provider acting as the only source of knowledge.
- Two organizations can use the same structural template with separate data, teams, decisions, versions and lifecycles.
- Any ongoing management arrangement states exactly what the provider may do, what needs local approval and how to stop or exit the service.

These are proposed acceptance criteria, not results from a delivered programme.

## Commercial and organizational fit

Possible revenue components are scoped onboarding, cohort or organization training, and optional recurring support. No fees or subscription are approved. Define capacity, actual delivery cost, support hours, tools/licences, travel where needed and member obligations before quoting an offer. There is no promise of permanently free Blueprint services.

The hospitality network’s free-founding/later-paid membership policy remains specific to that network. It does not automatically include training, authorize a new charge, create a managed-service agreement or enroll a member in central oversight. Any future bundle must state what is included and obtain agreement to the actual terms.

Suggested role allocation for review: UTP stewards the Blueprint’s common model; ODC may host the commercial offering; BAL may support entrepreneurship-oriented training later, but its start is deferred and it is not an initial delivery dependency. Exact provider entity, rights to materials, licensing, brand use, named humans and inter-project agreements remain open. Training revenue or service membership cannot affect Utkal Project’s editorial judgments.

## Decisions before external launch

Confirm the provider and service owner, target pilot audience, delivery capacity, exact service scope, training plan and assessment method, data access, commercial terms, support/exit responsibilities and participant-facing materials. Prepare the concrete review pack for the Founder and obtain the member organization’s own agreement before operating within it. No outreach, enrollment or service delivery is authorized by saving this design.
