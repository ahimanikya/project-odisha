# Organization charter

**UTP-CHR-001 · Draft v0.3 · For review**

**Mandatory human-reporting rule:** [ODB-GOV-001](HUMAN-AUTHORITY.md) records the Founder’s explicit direction: humans never report to AI. All human reporting lines remain human; AI assignments have named human supervisors. No local exception, temporary arrangement or delegated authority may reverse this relationship.

## Purpose and scope

Organize work that strengthens knowledge, cultural connection and opportunity around Odisha, while giving each initiative a clear purpose and accountable human leadership. The master Utkal Project has two distinguishable responsibilities: steward the common organizational framework, and deliver its own knowledge, heritage and community mission. Master status does not erase its own charter, backlog, budget or delivery lifecycle.

## Scope beyond the internal organization

The shared model is named **Odisha Blueprint**. It may be adopted by independent member organizations as an operating model with training and, where agreed, ongoing managed support. Internal Founder authority described here governs Utkal’s own organization and provider-side commitments. External organizations retain their own authorized human leadership; template adoption and membership do not transfer that authority or create internal reporting lines. The [central governance model](CENTRAL-GOVERNANCE.md) defines the proposed boundary.

## Founding authority

Ahimanikya remains the only appointed human initially and holds final authority over this planning organization. Founder & Editor-in-Chief is his established Utkal Project title. Other project-specific titles can be defined in their charters without changing his authority. No AI, committee label, project code, repository permission or template grants substitute authority.

Other humans may join only through an actual appointment. Human delegation, if later authorized, must specify the person, project, decisions allowed, limits, duration and revocation terms. Final reserved decisions stay with the Founder unless he explicitly changes that arrangement. Project independence is not a delegation by itself.

AI assistance cannot become a governing office, appoint or dismiss people, direct humans by asserted authority, evaluate employment consequences, award itself access, or approve its own recommendations. Human responsibility cannot be transferred to an agent. A person may voluntarily act on AI advice; the decision and accountability remain human.

## Hierarchy and reporting

Project hierarchy and personnel reporting are separate, explicitly documented structures. Follow the common [hierarchy and reporting format](HIERARCHY-AND-REPORTING.md) in every project. Each human assignment has one primary human manager; each AI assignment has a named accountable human supervisor. Functional collaboration does not silently create management authority. Ahimanikya currently holds all project accountability; future project-lead positions are unfilled proposals.

## Independent projects

Each project follows the same organizational model and structural template, maintaining its own purpose, charter, human owner, human and AI roster, personal JDs, working agreement, lifecycle, work backlog, outcomes, budget/resource assumptions and change history. Sharing a person, persona, template or brand does not merge those records.

A project can advance, pause, change direction or close without forcing other projects into the same state. It cannot commit another project’s money, people, data, brand, reputation or publication capacity without explicit authorization covering both sides.

Odisha Collective’s association with Utkal Project is organizational and mission-related; legal incorporation, ownership, contracting and financial structure remain undecided. BAC and BAL are intended parts of the Collective, with distinct project records and lifecycles. Farm resorts remain a future ODC concept, not an approved property acquisition or launched project. ODU’s exact relationship and offering remain open.

## Shared rules and local choices

The Founder’s current directions already require human primacy, final human gates, review before applying the template, truthful records and project identity. The proposed common baseline additionally standardizes approval traceability, least necessary access, attribution, independent records and version history.

Within the common structure, project charters can define different audiences, deliverables, membership, staffing, local work rules, domain review, metrics and release cadence. They do not replace the shared model with an unrelated organizational structure. They cannot use a local exception to claim AI authority or silently change a Founder-reserved decision. A conflict with the common baseline is brought to the Founder with the exact proposed change; a child project cannot settle it by declaring itself exempt.

## Relationship and conflict management

Document shared work with a bounded agreement: purpose, owners, outputs, costs, brand/data use, dependencies, exit and approvals from the authorized humans. Initially the same Founder can approve both sides but the affected project scopes must still be explicit.

Keep encyclopedia editorial judgment separate from Collective commercial participation. A membership payment, owned property, BAC or BAL programme cannot buy favourable factual coverage. Record conflicts where the Founder or a contributor has multiple roles; use appropriate human review where needed and preserve the disclosure.

People’s consent and external commitments remain distinct from internal authority. Founder approval does not constitute a member’s acceptance, partner agreement or contributor permission.
