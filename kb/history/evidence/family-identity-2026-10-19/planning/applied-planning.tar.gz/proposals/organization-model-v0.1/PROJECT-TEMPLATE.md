# Odisha Blueprint — shared project template

**ODB-TPL-001 · Draft v0.4 · Design only; no executable template installed**

**Mandatory human-reporting rule:** [ODB-GOV-001](HUMAN-AUTHORITY.md) records the Founder’s explicit direction: humans never report to AI. All human reporting lines remain human; AI assignments have named human supervisors. No local exception, temporary arrangement or delegated authority may reverse this relationship.

The [proposed common working rules](CORE-WORKING-RULES.md) form the candidate baseline for each project’s local agreement. The [rule review](RULE-REVIEW.md) records the proposed provisions and their intended scope. Neither document is an adopted policy package yet.

## Same model and structure, independently governed instances

Utkal Project and every participating project use the same structural template, **Odisha Blueprint**. Member organizations can adopt their own instances under their own human governance. Each owns the governing contents, decisions and adopted version of its instance. Structural sections and record types stay common; independent governance is exercised within them. The template supplies prompts, record formats and common governance rules; it does not copy UTP’s mission, team, technology, pricing or operating commitments into other projects.

Proposed common project package, used consistently by every project:

```text
<project-code>/
  README.md                 # identity, scope, current state, links
  charter.md                # mission, audiences, human authority, boundaries
  working-agreement.md      # local collaboration and decision rules
  organization.md           # project hierarchy and organizational relationships
  reporting.md              # human reporting lines, AI supervision and escalation
  team.md                   # approved roster; distinguish vacancies/proposals
  roles/                    # versioned role profiles and personal JDs
  membership-lifecycle.md   # adopted Joiner–Mover–Leaver process and local responsibilities
  plan.md                   # outcomes, phases, resources and dependencies
  requirements.md           # PRD or domain-appropriate programme requirements
  work/                     # briefs, reviews and delivery evidence
  decisions/                # actual human decisions and their source references
  relationships.md          # agreements and cross-project dependencies
  history/                  # baselines, changes and adoption records
  project-profile.json      # code, pinned versions and record locations
  blueprint-adoption.md     # adopted version, local human decision and exceptions
  service-scope.md           # agreed provider support/access or explicitly not applicable
```

This is a design for review, not a directory scaffold that activates processes. Privacy-sensitive records may live in approved restricted storage; public files contain safe references only. One repository with separate folders or several repositories can both support the model. Repository strategy remains a later choice.

## Typed people and AI assignments

The proposed [member-type model](MEMBER-TYPES.md) uses an explicit identity kind independent of JD title and document type. Template instances must represent identity, project assignment, reporting and permission separately. Validation must resolve reporting targets to human actors; a Project Manager title cannot override the human-only reporting rule. Detailed fields and validators remain design/build work.

## Joiner–Mover–Leaver

The Founder has adopted [JML](JML-LIFECYCLE.md) as a common Blueprint process for both humans and AI. Each project uses its own event records, human decisions, assignments and access evidence. Event templates and technical validation are ODB build work; template adoption never creates an appointment automatically.

## Minimum profile

Each project records its stable code and name; purpose and outcomes; sponsor/accountable human; organization placement; primary human reporting lines; AI supervision; functional relationships and escalation route; coordination relationship and independently specified legal relationship if known; lifecycle state; decision home; local charter/agreement versions and approval state; template version; team and access records; work location; data classification; dependencies; budget assumptions; open decisions; last review and change history.

For external instances, also record organization namespace, local accountable human, provider contact if applicable, participation mode, permitted central reporting, management scope and exit responsibilities. The same fields can be marked not applicable for an internal project with no service provider.

Draft fields remain visibly unfilled until actually decided. Do not manufacture an active roster, funding commitment or approval to make the profile look complete.

## Shared baseline and project variation

| Shared structure | Defined separately in each project |
|---|---|
| Human authority and traceable authorization | Named humans, reserved decisions and explicit delegations |
| Charter format and independent lifecycle record | Mission, audiences, outcomes and lifecycle state |
| Hierarchy and reporting record formats | Project placement, human managers, AI supervisors, reporting cadence and escalation |
| Joiner–Mover–Leaver process | Local event owners, actual approvals, access changes, handover and closure evidence |
| Human/AI labels and JD fields | Team composition, specialist titles, persona assignments |
| Work, review and release evidence formats | Delivery method, cadence and domain-specific acceptance |
| Privacy, attribution and truthful reporting | Relevant datasets, consent, publication and access scopes |
| Template-version and history mechanism | Adoption timing and approved local variations |

Shared rules cannot be silently weakened by a local template edit. Different contents within the shared sections are normal local governance choices. A change to the shared structure itself is a template-change proposal, not an undocumented local fork. Each profile explains which clauses are common and which are project-specific.

The [hierarchy and reporting specification](HIERARCHY-AND-REPORTING.md) supplies the common fields. Every instance distinguishes current appointments from proposed positions and records the authority behind each reporting relationship.

## Version adoption and upgrade

Pin the template version per project. A template change is released as a proposal with a change log, compatibility notes and exact diff. Assess its effect separately in UTP, ODC, ODU, BAC and BAL. The authorized human chooses adoption, deferral or a documented revision for each (the Founder for internal reserved decisions, the member’s own authorized human for an external instance); approval for UTP is not blanket approval for all projects.

Preserve previous charters, agreements, JDs and approval records; never silently propagate updated persona prompts or access. An upgrade must identify the new local versions, migration steps, verification and any newly requested authority. A project’s deferred upgrade does not erase the Founder’s current instructions.

Central comparison and reporting follow [the fleet model](CENTRAL-GOVERNANCE.md). Shared structure enables visibility, but actual access and execution require an approved scope and implemented controls.

## Initial instantiation

The Founder has set the sequence: **UTP → ODC → ODU**, with **BAL and BAC deferred**. Prepare UTP as the first complete instance, then apply its lessons to separately governed ODC and ODU instances. Keep deferred initiatives as concept records without launch or staffing work. The [adoption plan](ADOPTION-PLAN.md) describes UTP’s concrete preparation package and proposed readiness evidence. The order is confirmed; each actual version adoption and application remains recorded separately.
