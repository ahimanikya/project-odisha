> Current application status: see [CURRENT-STATE.md](CURRENT-STATE.md). Historical review wording below is retained; UTB-DEC-005 and the application record govern the approved batch.

# Odisha Blueprint — organization and governance model

**Odisha Blueprint — created by Ahimanikya Satapathy, Founder & Editor-in-Chief of Utkal Project.**

See the [authorship and discussion-before-reuse direction](MODEL-AUTHORSHIP.md).

**ODB-GOV-008 · Draft v0.11 · 27 September 2026 · Prepared for review, not installed**

Utkal Project is the master project and also a project in its own right. Odisha Collective, Odisha Unbound, Bhubaneswar Alpha Lab (BAL), Bhubaneswar Athletic Club (BAC) and future projects have distinct identities and independent lifecycles. They use the same organizational model, structural template and record types. Each independently governs its own purpose, charter, team, local working rules and lifecycle within that common structure. Humans direct and remain accountable; AP, AI personas and agents assist them.

This package records the Founder’s latest direction and proposes the details needed to make it workable. It does not approve every draft rule, launch a project, activate agents or modify the canonical OKF, existing PRD baselines, platform instructions or delivery pipeline.

**Odisha Blueprint** is the Founder-selected name for this shared template and future operating-model/training offering. It supports internal Utkal projects and, through explicit adoption and service agreements, independent member organizations.

**Adoption order confirmed:** Utkal Project → Odisha Collective → Odisha Unbound. BAL and BAC will start later. The [adoption plan](ADOPTION-PLAN.md) defines the first UTP preparation package and distinguishes planned adoption from approval and application.

**Project prefixes:** Utkal Project uses **UTP**, Odisha Collective **ODC**, and Odisha Unbound **ODU**. Earlier UP, UC and UU codes remain historical aliases; existing decisions and requirements keep their identity.

**Naming convention agreed:** **ODB** identifies shared Odisha Blueprint records; UTP, ODC, ODU, BAL and BAC identify project records. The record-type labels in the [identifier register](PROJECT-REGISTER.md) are also agreed. This naming approval does not adopt the full draft operating model.

**Two connected workstreams:** [build ODB](../../subprojects/utkal-blueprint/README.md) as the reusable Blueprint, and build UTP as the knowledge project and first adopter. Blueprint development has its own backlog; adoption alone is not the Blueprint product.

**JML adopted:** the Founder has adopted Joiner–Mover–Leaver into the Blueprint. [ODB-GOV-004](JML-LIFECYCLE.md) records the human and AI paths. This adopts the lifecycle process; specific member events and technical controls still need their actual authorization and implementation.

**Complete rules for review:** [Utkal operating rules, edition 0.2](../rules-review-v0.1/UTKAL-RULES-FOR-REVIEW.md). The documentation now stands on its own. See the [history note](HISTORY-EDIT-NOTE.md) for the explicitly edited historical copies.

## Read the model

| Document | Purpose |
|---|---|
| [Final baseline and first-use package](../../releases/initial-baseline-v0.1/REVIEW.md) | Exact 21-file repository payload, remaining choices and bounded activation scope; final approval pending |
| [Practical JML checklist](JML-CHECKLIST.md) | Founder-approved checklist wording; actual events remain separately authorized |
| [First UTP onboarding plan](UTP-ONBOARDING-PLAN.md) | First-use approach approved; exact package and activation pending |
| [Full member names](MEMBER-NAMES.md) | Ahimanikya Satapathy confirmed; AI surname suggestions for selection |
| [Role and JD standard](ROLE-AND-JD-STANDARD.md) | Next review: shared identity, duties, supervision and assignment fields |
| [Initial UTP team and JDs](UTP-INITIAL-TEAM.md) | Next review: Founder and four personas across eight responsibility profiles |
| [Working agreement approval](WORKING-AGREEMENT-APPROVAL.md) | Human decision and exact reviewed working agreement |
| [Blueprint governance and decision gates](BLUEPRINT-GOVERNANCE.md) | Founder-approved wording: shared authority, reporting, decision rights and proportionate gates |
| [Governance approval record](GOVERNANCE-APPROVAL.md) | Human decision and exact reviewed governance version |
| [Charter approval record](CHARTER-APPROVAL.md) | Human decision, exact reviewed version and limited approval scope |
| [Blueprint founding charter](BLUEPRINT-CHARTER.md) | Founder-approved charter wording; shared baseline, independent adoption and human authority |
| [Adoption plan](ADOPTION-PLAN.md) | Confirmed UTP → ODC → ODU sequence; BAL and BAC deferred |
| [Typed human and AI members](MEMBER-TYPES.md) | Separate human/persona identity from role, authority and document type |
| [ODB development workstream](../../subprojects/utkal-blueprint/README.md) | Reusable package, validation, UTP feedback and release work |
| [Humans report only to humans](HUMAN-AUTHORITY.md) | Founder-directed rule applying to every Blueprint instance; no exceptions |
| [Joiner–Mover–Leaver lifecycle](JML-LIFECYCLE.md) | Adopted process: approved entry, controlled change, handover and access closure |
| [Utkal rule review](RULE-REVIEW.md) | 35 proposed operating provisions and scope decisions |
| [Shared working agreement](CORE-WORKING-RULES.md) | Founder-approved wording: twelve common working provisions and practical arrangements; v0.2 |
| [Odisha Blueprint definition](UTKAL-BLUEPRINT.md) | Named model, scope, intended offering and staged development |
| [Central governance and fleet management](CENTRAL-GOVERNANCE.md) | Shared oversight, independent member authority and scoped management services |
| [Offering and training](OFFERING-AND-TRAINING.md) | Onboarding, practical learning, pilot outcomes and optional ongoing support |
| [AI Project Coordinator](AI-PROJECT-COORDINATOR.md) | Shared role profile: planning, dependencies, status and human review support |
| [Disha’s UTP coordinator JD](UTP-DISHA-COORDINATOR.md) | Proposed first project assignment, reporting line and authority limits |
| [Organization charter](ORGANIZATION-CHARTER.md) | Master project, project relationships and human authority |
| [Hierarchy and reporting](HIERARCHY-AND-REPORTING.md) | Project hierarchy, current human accountability, future reporting lines and AI supervision |
| [Governance and lifecycle](GOVERNANCE.md) | Decision rights, gates, delegation and independent project states |
| [Human and AI working agreement](HUMAN-AI-AGREEMENT.md) | AP as an assisting co-worker; roles, JDs, permissions and accountability |
| [Shared project template](PROJECT-TEMPLATE.md) | Required records and where each project can differ |
| [Project and identifier register](PROJECT-REGISTER.md) | UTP, ODC, ODU, BAL, BAC and legacy references |
| [Decision record](DECISIONS.md) | Founder-directed principles, proposed details and adoption history |
| [Structured registry](project-register.json) | Machine-readable draft identities, relationships and version pins |

## Same structure, independent governance

Every project has the same structural places for its charter, organization hierarchy, human authority, reporting lines, team/JDs, working agreement, decisions, work and lifecycle. The contents and authorized decisions belong to that project. A shared template upgrade does not automatically change a project’s governing documents. An external member uses the same structure with its own authorized human leadership; it does not become an internal subsidiary or inherit our reporting chain. Independent governance does not permit AI authority or remove the Founder’s reserved final gate.

## Organization map

```mermaid
flowchart TD
  H["Ahimanikya · human Founder · final authority"] --> UTP["UTP · Utkal Project
Master project + own knowledge mission"]
  UTP -->|"organizational coordination; independent lifecycle"| ODC["UTC · Utkal Collective"]
  ODC -->|"intended inclusion"| BAC["BAC · Bhubaneswar Athletic Club"]
  ODC -->|"intended inclusion"| BAL["BAL · Bhubaneswar Alpha Lab"]
  UTP -.->|"project recognized; placement to confirm"| ODU["UTU · Utkal Unbound"]
  T["Shared template · project-specific adoption"] -.-> UTP
  T -.-> ODC
  T -.-> ODU
  T -.-> BAC
  T -.-> BAL
  AI["AP / AI personas / agents
Assistance under human direction"] -.->|"scoped assignments; no governing authority"| UTP
```

Arrows describe planning relationships, not legal ownership or unrestricted access. Odisha Collective remains independently operated and closely associated with the knowledge initiative. The master role coordinates shared purpose and governance; it does not merge editorial and commercial decisions. Odisha Unbound is now recognized as a distinct project identity following the Founder’s latest statement. Its earlier suggested traveller-facing brand role and exact place under the Collective remain proposals.

## Reporting and accountability

The [reporting structure](HIERARCHY-AND-REPORTING.md) separates project placement, human line management, AI supervision and collaboration. Currently the Founder is the only human. Future human project leads and reporting lines are proposals, with appointments and authority recorded separately. AI personas have no human direct reports.

## What changes from the earlier team proposal

The earlier model concentrated on one encyclopedia team. This model establishes a family of projects, with Utkal Project itself using the same project template. The four approved AI persona names remain available role identities; no project automatically inherits all four, their JDs or their access. Editor titles suit the knowledge team; another project may need human coaches, programme leads, operators or mentors with its own approved JDs.

The [earlier team packet](../team-model-v0.1/README.md) remains useful as a draft UTP team profile. Its generic TM references now have UTP-prefixed aliases, with the original review index preserved. Its detailed charter and JDs have not become an organization-wide mandate.

## Review status

The Founder has directed the master/project structure, same model and structure with independently governed project contents, project-based prefixes, written governance and human primacy. Project prefixes and record-type labels are agreed. Detailed file structure, lifecycle labels, future reporting lines, gate mechanics and implementation mechanics remain proposals. The adoption order is already Founder-directed. The [previous draft archive](history/organization-model-v0.1.zip) and [version register](history/version-register.json) preserve the earlier model. The folder retains its original name; the current review package is v0.11. The version register preserves v0.2 before the Blueprint/service extension and v0.3 before the adoption-sequence decision. The Founder has selected **Odisha Blueprint** as the template name, superseding the earlier “Living Knowledge Studio” suggestion. The extension to member organizations and a training/operating-model offering are confirmed direction; specific delivery terms remain proposals.

Review this package as a concrete organizational design. A later approved adoption can create each project’s own profile and prepare exact OKF/PRD changes. No additional service, repository or hosting is needed merely to model the organization.
