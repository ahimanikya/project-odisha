# Odisha Blueprint — rule review

**ODB-GOV-003 · Proposed operating provisions · Not adopted as a package**

This review sets out Utkal’s candidate working provisions, with human authority, independent project governance and the separately adopted JML direction preserved. Detailed approval and implementation remain separate.

| Clause | Topic | Proposed Utkal provision | Timing |
|---|---|---|---|
| 01 | Human approval and the final gate | Authorize bounded preparation, then retain the Founder’s actual result/application gate; permit one decision for a fully prepared batch. | Core now |
| 02 | Prepare a decision-ready proposal | Prepare a concrete proposal and useful preview; interpret the actual request and existing scope instead of treating question grammar as a universal stop. | Core now |
| 03 | Use bounded batches | Use coherent bounded batches with exact outputs, scope and external effects; avoid approval for every minor edit. | Core now |
| 04 | Project-specific teams and working arrangements | Typed identities, scoped JDs and separate project rosters; agree availability with humans. | Core now |
| 05 | Candour and respectful challenge | Make uncertainty and mistakes visible; preserve evidence even when inconvenient. | Core now |
| 06 | One authoritative work record per project | One work record per project; coordinated views link to it. Record preparation, review, human approval and application separately. | Core now |
| 07 | Verify real behavior at the appropriate layer | Verify actual behavior at the appropriate layer with permitted test data and human-authorized trials; leave unverified paths visibly incomplete. | Domain guidance when relevant |
| 08 | Read before editing and preserve traceability | Bounded reviewable edits, source-backed generated views, evidence tied to the candidate; use the chosen Git workflow. | Core now |
| 09 | Concurrent editing: defer global locking | Prevent conflicting edits now through bounded ownership and isolated work; introduce locking only after real concurrent writers and a reviewed design. | When concurrent writers justify it |
| 10 | Template copies do not appoint members | A copied role profile remains a profile. Record each actual project assignment, human approval and access scope. | Never import this mechanism |
| 11 | Versioned release and project adoption | Separate draft, approved, applied and verified states; release shared rules explicitly and record each project’s adoption. | Core now |
| 12 | Credit contributions fairly | Credit creator, human decisions/context and AI assistance at a useful level. | Core now |
| 13 | Improve from observed work | Record recurring issues and proposed improvements; route global changes to ODB and local ones to their project. | Core now |
| 14 | Keep records identifiable without unnecessary paperwork | Use a small identity/version/status/owner/source/decision core and optional domain metadata; integrate with the existing OKF format when approved. | Core now, schema detail for review |
| 15 | Protect contributor and organizational data | Protect contributor, family, guest and member data; use authorized inputs and permitted test records; retain a redacted incident trail. | Core now |
| 16 | Evidence-led content and useful design | Trace published claims and computed values to sources; design important states before implementation and identify seed/demo content. | Core now |
| 17 | No mandatory duplicate website implementation | Use the approved UTP delivery approach; prototype only where it answers a real question. | No requirement to import |
| 18 | Review the actual candidate | Tie findings to actual criteria/revision; independently review when available and disclose self-review. | Core now |
| 19 | Quality findings do not confer release authority | Drishti reports honest findings; the relevant human authorizes release. Accepted risks retain the original finding. | Core now |
| 20 | Human membership and accountability | Use these as optional participation patterns with personal JDs and human reporting, not mandatory A/B/C labels. | Core now; expand on actual appointment |
| 21 | Joiner: establish a valid assignment | Small welcome/read pack; human acknowledgement or verified AI setup as appropriate; actual scoped authorization. | Core now |
| 22 | Mover: change responsibilities and review access | Review both granted and removed access; update reporting and assignments with dated history. | Use on actual role change |
| 23 | Leaver: close work and verify access removal | Revoke actual accounts, tokens, sessions and integration access; archive contributions appropriately. | Use on actual departure |
| 24 | History with appropriate privacy protection | Preserve decisions and accountability while permitting authorized redaction/restriction of exposed private information. | Core now |
| 25 | Stable identifiers and explicit relationships | Use the agreed PREFIX-TYPE-NNN scheme, stable aliases and explicit relationships; keep versions distinct from IDs. | Core now |
| 26 | Scale review to consequences; delegate explicitly | Assess impact and reversibility to scale review; internal delegation exists only through the Founder’s actual human assignment. | Core now |
| 27 | Keep identity, role and permissions separate | Use the proposed single-source human/persona kind and stable actor IDs, with project-specific assignments. | Core now; typed implementation pending |
| 28 | Separate accountability, supervision and approval | Separate accountable human, supervisor and approval authority; never infer delegation from one generic name field. | Core now |
| 29 | A common Blueprint without a mandatory software stack | Keep ODB provider-neutral and the agreed UTP stack; select sensible structure and tests per implementation. | Optional engineering guidance only |
| 30 | Defer database migration machinery | Use reviewed versioned data/schema changes if a real schema evolves; do not adopt Knex or a database to satisfy the template. | When actual data evolution requires it |
| 31 | Defer API and integration architecture | Keep single-source contracts as a design option for future APIs; build services only for an approved need. | When an actual API is commissioned |
| 32 | Use the approved hosting and deployment approach | Retain reproducible reviewed deployment as a goal; use UTP’s approved hosting and delivery plan. | No AWS mandate |
| 33 | Protect secrets and scope technical access | Keep secrets out of repositories/artifacts, scope access and prepare revocation/rotation after exposure; choose storage for the actual platform. | Software/domain guidance when relevant |
| 34 | Apply meaningful quality checks equally | Use meaningful automated quality checks for code and schema; standards apply regardless of human or AI authorship. | ODB/UTP implementation |
| 35 | Use reproducible dependencies and deliberate upgrades | Pin tested versions, use reproducible installs, triage findings and justify new dependencies. | ODB/UTP implementation |

The [core working rules](CORE-WORKING-RULES.md) give the concise candidate agreement. The [complete rule wording](../rules-review-v0.1/UTKAL-RULES-FOR-REVIEW.md) provides the current review edition. These documents do not activate personas or install controls.
