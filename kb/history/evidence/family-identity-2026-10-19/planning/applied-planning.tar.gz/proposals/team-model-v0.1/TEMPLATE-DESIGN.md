# Odisha Blueprint — earlier UTP team design input

**Proposal v0.1 · 27 September 2026 · FOR REVIEW ONLY · NOT ADOPTED**

**Odisha Blueprint** is now the Founder-selected name, superseding the earlier Living Knowledge Studio suggestion. The [current Blueprint definition](../organization-model-v0.1/UTKAL-BLUEPRINT.md) broadens the model to organizations, central oversight and member training; this earlier draft remains a knowledge-project-specific input, not the full common model. Utkala · Odisha is the first project it would serve. The template would be a new, independently maintained model for a human-led knowledge publication with AI assistance—not a renamed installation of the reference template.

## What makes it different

The unit of work may be a historical claim, oral history, photograph, translation, dataset, community programme or software feature. Its quality depends on evidence, context, consent and attribution as well as functioning code. The Founder retains final authority over the whole project, and named AI personas help prepare work without becoming substitute human authors, scholars or decision-makers.

The template should preserve three linked histories: how knowledge changed, how the product changed, and who contributed or authorized each change. “Verified” needs a stated meaning: schema validation, source comparison, human subject review and observed software behavior are different kinds of evidence.

## Proposed layers

| Layer | Reusable part | Utkala-specific part |
|---|---|---|
| Governance | Charter, working agreement, role/JD format, authority rules | Founder identity and approved memberships |
| Knowledge practice | Sources, uncertainty, credit, corrections and consent boundaries | Odisha subjects, languages, heritage taxonomy and evidence standards |
| Product and delivery | PRD history, bounded briefs, reviews, approval/release records | Website journeys, contribution channels and chosen stack |
| AI collaboration | Role briefs, permission boundaries, evidence reporting | Approved persona names and assignments |
| Community and learning | Contributor onboarding, reviewer scope, learning plans | Local/diaspora relationships and approved internship programmes |
| Optional tooling | Validations, publication export and build/deploy adapter interfaces | Existing OKF tools, Astro, GitHub Pages and approved Firebase features |

The core would not prescribe AWS, a corporate reporting hierarchy, an AI vendor, a front-end framework or a fleet synchronization system. A project profile would record its choices explicitly. Template updates would arrive as proposals with diffs; they would never propagate automatically.

## Proposed fresh AI roster — four personas

| Handle | Role | Primary output |
|---|---|---|
| **Disha** | Product Steward & Team Coordinator | PRD, briefs, work record, review packs and handovers |
| **Anvesha** | Research Editor & Knowledge Steward | Source-linked research, taxonomy, provenance, archives and credit |
| **Samanta** | Experience Designer & Engineer | Website experience, implementation and knowledge tooling |
| **Drishti** | Quality Reviewer | Acceptance evidence, candid findings and publication-readiness checks |

The Founder has approved all four names. The technology persona is **Samanta Chandrasekhar**, called **Samanta**, named in honour of the astronomer known as Pathani Samanta. Role assignments and activation remain pending. They do not claim a historical identity, human credentials or actual appointment. The role remains meaningful if the Founder renames a persona or changes its underlying model. A persona is a role configuration, not an autonomous team member with inherent tool permissions.

Ahimanikya is the only human member initially. Future human Editors may take on a subject or functional remit when he appoints them; they do not automatically replace an AI persona or acquire the final gate.

## Building the template over time

1. Review and approve the operating documents and roster.
2. Pilot them on one small knowledge package and one small website change, using the existing project environment.
3. Inspect friction and missing evidence; revise the documents through the Founder’s gate.
4. Propose only the tooling that the pilot justifies, with tests and a reviewable change set.
5. Package a reusable starter after the process has worked in practice, with a clean separation between generic structures and Utkala content/private records.

This task produces the design proposal only. It does not create a template repository, install persona prompts, activate agents or alter the current pipeline.
