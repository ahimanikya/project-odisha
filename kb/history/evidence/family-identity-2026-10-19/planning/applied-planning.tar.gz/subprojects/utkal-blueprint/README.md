# ODB — Odisha Blueprint development

**Build workstream v0.1 · 27 September 2026 · Planning and design**

The Founder directed: **“Apart from building UTP, we also need to build the Blueprint”.** ODB is therefore tracked as a development workstream in its own right, alongside UTP’s product work and first adoption. It is not just a prefix for documents. This does not create another company, deploy a service or approve the entire draft operating model.

## Two connected deliverables

| Workstream | Owns | Produces |
|---|---|---|
| **ODB — build the Blueprint** | Reusable organizational structure, typed roles, governance formats, validation design, adoption guidance and training materials | A versioned template package and, after review, supporting tools and learning material |
| **UTP — build Utkal Project and adopt the Blueprint** | Its encyclopedia/knowledge mission, website, content, own charter/team and real delivery work | Project outcomes plus evidence and feedback from using a particular Blueprint version |

ODB owns generic corrections; UTP owns its local choices. UTP’s website/content delivery and Blueprint adoption are related work, but completing one does not complete the other. The Founder remains the human owner and final decision-maker for both; no additional team members or agents are activated.

ODB development follows the same human-led record structure as other projects. Its own charter/team instance and version adoption must be reviewed; tracking it as a builder does not exempt it from the Blueprint’s governance principles.

## Build sequence

1. **Define the core.** Complete the common structure, identity/assignment model, human reporting rules, record identifiers and approval boundaries. Current state: reviewable drafts exist; the role/type details remain proposed.
2. **Package a first reusable version.** Produce generic templates with explicit placeholders, an example instance, a manifest and adoption instructions. Keep UTP-specific names, roles and private data out of generic defaults. Current state: not packaged.
3. **Build proportionate validation.** Check schema/IDs, typed identity, reporting references, human-only authority, version records and activation evidence. Use meaningful valid/invalid examples; source-model checks cannot prove a recorded human approval actually happened. Current state: requirements documented; validators not implemented.
4. **Review and pilot in UTP.** Prepare the exact local instance and application changes. Exercise the approved model on one real bounded task and retain the evidence. Current state: adoption plan drafted; no completed adoption claimed.
5. **Refine and release.** Turn observed issues into ODB work items, preserve versions and prepare a reviewed release candidate. Let each adopter decide its upgrade; no silent propagation.
6. **Expand to ODC, then ODU.** Apply the same structure with independently governed local contents. BAL and BAC remain deferred. External member services and training rollout remain later proposals.

This sequence is the proposed implementation method. The confirmed adoption order remains **UTP → ODC → ODU**. ODB is the product-building workstream enabling that order, not an extra adopter inserted before UTP.

## Boundaries between building and adopting

Preparing Blueprint source and documentation is different from applying the template to an organization. Installation, canonical KB/PRD changes, role activation, permissions and deployment must be covered by the Founder’s actual approval. The immediate reviewable work is design and planning; no executable template or tool installation is implied.

UTP can continue independently authorized knowledge and website preparation while ODB is developed. A UTP role, gate or release that depends on the new Blueprint waits for the relevant reviewed adoption. Feedback from UTP does not automatically become global policy.

## Records and next work

- [Blueprint design package](../../proposals/organization-model-v0.1/README.md)
- [Proposed human and AI identity model](../../proposals/organization-model-v0.1/MEMBER-TYPES.md)
- [UTP adoption plan](../../proposals/organization-model-v0.1/ADOPTION-PLAN.md)
- [Utkal rules assessment](../../proposals/organization-model-v0.1/RULE-REVIEW.md) and [candidate core rules](../../proposals/organization-model-v0.1/CORE-WORKING-RULES.md)
- [Adopted JML process](../../proposals/organization-model-v0.1/JML-LIFECYCLE.md) — lifecycle templates and verification requirements are now explicit ODB build work
- [ODB work backlog](BACKLOG.json)

The backlog names deliverables, dependencies and acceptance evidence. It contains proposals rather than commitments or completed implementation. No repository location, public licence, cloud service, delivery date or budget has been selected by this workstream record.
