# Odisha Collective — direction and portfolio

**Direction record v0.5 · 27 September 2026 · Planning only**

Odisha Collective is the name the Founder is developing for an independent initiative closely associated with Utkal Project. The conversation has expanded its intended scope beyond a hospitality alliance to include future farmland-and-resort developments, Bhubaneswar Athletic Club and a proposed Bhubaneswar Alpha Lab. This records the intended portfolio; it does not establish a company, legal ownership structure, operating club or launch commitment.

The newer [organization model](../../proposals/organization-model-v0.1/README.md) places this portfolio in the master Utkal Project context while preserving independent governance. All projects use the same structural template. BAC and BAL retain their own charters, teams, decisions and lifecycles within the Collective relationship. Odisha Unbound is now recognized as a distinct project identity; its exact operating role and placement remain open.

## Adoption sequence

The Founder has set **UTP → ODC → ODU** as the initial Blueprint adoption order. **BAL and BAC start later** and remain deferred concepts. This sets the sequence, not a launch date or completed adoption. See [the adoption plan](../../proposals/organization-model-v0.1/ADOPTION-PLAN.md). Initial Blueprint training and rollout must not depend on BAL starting.

## Recorded direction

| Area | Founder’s direction | Current scope |
|---|---|---|
| Hospitality member network | Independent owners, practical quality improvement, shared marketing and referrals; membership initially free with a disclosed later paid phase | [Existing hospitality planning sub-project](../hospitality-alliance/README.md); detailed model remains for review |
| Future farm resorts | The Founder may build properties combining farmland and a resort | Long-term idea; no site, acquisition, design, budget or development approved |
| Bhubaneswar Athletic Club (BAC) | “I also have idea around BAC - which is Bhubaneswar Athletic Club that will be part of Utkal Collective” | Intended inclusion confirmed; club offering and operating model undefined |
| Bhubaneswar Alpha Lab (BAL), proposed name | The Founder introduced “BAL - Bangalore Alpha Lab” and suggested “Bhubaneswar Alpha Lab” for young entrepreneurs’ training camps or incubation | Concept within the Collective; naming adaptation and programme format remain to be developed |

Utkal Project remains the associated knowledge, heritage and community initiative. Odisha Collective has a broader intended business scope. The exact legal and operating relationship remains to be designed.

## Bhubaneswar Athletic Club

**Name:** Bhubaneswar Athletic Club. **Short name:** BAC. **Intended home:** Odisha Collective.

The Founder has named the idea and its place in the Collective. Sports, audiences, facilities, coaching, events, membership structure, location, ownership arrangements and funding have not yet been specified. An athletics-focused club, a multi-sport club and a wider recreation club remain different possible interpretations; none is selected here.

For a later concept brief, define who BAC serves, its first useful offering, the facilities and people needed, and how participation works. Connections to farm resorts or hospitality experiences can be explored later without assuming BAC must share a site or bundle memberships.

The hospitality network’s free-to-paid founding policy applies to that network. It does not automatically set BAC membership prices or terms, or the pricing of future farm resorts.

## Bhubaneswar Alpha Lab

**Proposed name:** Bhubaneswar Alpha Lab. **Short name:** BAL. **Intended home:** Odisha Collective. **Audience:** young entrepreneurs.

The Founder’s wording was: “And then BAL - Bangalore Alpha Lab, I can call that Bhubaneswar Alpha Lab, for young entrepreneurs' training camp or incubation”. This records a possible adaptation of the name; it does not establish whether Bangalore Alpha Lab is an existing organisation, rename such an organisation or assume any affiliation.

Two possible offerings should be scoped separately:

- **Entrepreneurship camps:** time-bounded practical learning around customer discovery, idea validation, prototypes and business fundamentals. These topics are proposed, not a committed curriculum.
- **Incubation:** continuing support for selected founders through mentoring, venture development and access to relevant networks. Duration, selection criteria, mentor capacity and resources remain open. No funding or investment is promised.

A practical starting proposal is one small, mentor-led camp before committing to an ongoing incubator. Future farm resorts could host residential programmes, but BAL need not wait for a property development or require its own campus. Connections to Odisha’s hospitality, agriculture, culture and sport could provide real problems for participants to explore without restricting the programme to those sectors.

Before a programme brief is approved, define participant stage and age range, learning outcomes, delivery format, human mentors, budget, fees or scholarships, and follow-up support. The hospitality membership policy does not determine BAL’s pricing. Equity, investment and intellectual-property arrangements are undecided and must not be implied by participation.

## Odisha Blueprint offering

The Founder has named the shared human–AI organization template **Odisha Blueprint** and directed that it become an operating-model and training offering, extendable to member organizations with central oversight and agreed management support. The [Blueprint definition](../../proposals/organization-model-v0.1/UTKAL-BLUEPRINT.md) and [offering design](../../proposals/organization-model-v0.1/OFFERING-AND-TRAINING.md) record this direction. ODC as commercial delivery home and BAL as a possible training contributor are recommendations for review, not appointed responsibilities. Blueprint services do not automatically become part of hospitality membership or transfer member leadership authority.

## Names and brand roles

- **Odisha Collective:** current umbrella name in the Founder’s planning direction; replaces Utkal Hospitality Alliance as the broader naming direction.
- **Odisha Unbound:** now explicitly identified by the Founder as a project. Its use as a traveller-facing brand was suggested earlier and remains an option; exact placement and operating scope are open.
- **Bhubaneswar Athletic Club / BAC:** intended initiative within Odisha Collective.
- **Bhubaneswar Alpha Lab / BAL:** proposed name for the young-entrepreneur training/incubation initiative, following the Founder’s reference to Bangalore Alpha Lab.

No name, trademark or domain availability has been checked. Specific entity structures are not determined by this portfolio map.

## Historical continuity

The hospitality [PRD v0.1.0](../hospitality-alliance/PRD.md) and preserved baseline remain the earlier hospitality-only specification. This direction record does not silently expand those requirements to BAC, BAL or property development. Future product briefs and revisions should reference this record and preserve prior baselines.

- **v0.1:** Recorded the Collective umbrella, hospitality network, future farm resorts and BAC; Odisha Unbound retained as an optional brand name.
- **v0.2:** Added the Founder’s proposed Bhubaneswar Alpha Lab name and entrepreneurship camps/incubation direction. Programme recommendations are distinguished from the Founder’s stated concept.

The Founder remains the final decision-maker for this planning work. Recording an idea is not approval to recruit, launch, purchase land, incur costs or create external commitments.

- **v0.3:** Linked the shared organizational structure and independently governed projects; recognized Odisha Unbound as a project identity while leaving its exact role open.

- **v0.4:** Linked the Odisha Blueprint offering direction. Commercial and training delivery ownership remain to be assigned.

- **v0.5:** Recorded ODC as the second adopter after UTP, followed by ODU; BAL and BAC are deferred.
