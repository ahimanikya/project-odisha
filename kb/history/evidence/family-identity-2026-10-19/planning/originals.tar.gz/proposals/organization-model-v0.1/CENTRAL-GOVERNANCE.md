# Central governance and fleet management

**UTB-GOV-011 · Draft v0.3 · For review**

Utkal Blueprint provides the common structure for governing a group of participating projects and organizations. Central oversight and independently governed instances coexist through explicit responsibilities, shared reporting formats and approved management scope.

**Mandatory human-reporting rule:** [UTB-GOV-001](HUMAN-AUTHORITY.md) records the Founder’s explicit direction: humans never report to AI. All human reporting lines remain human; AI assignments have named human supervisors. No local exception, temporary arrangement or delegated authority may reverse this relationship.

## Authority domains

| Domain | Accountable human | Central role | Local role |
|---|---|---|---|
| Blueprint stewardship | Founder initially; any future steward explicitly appointed | Maintain template, standards, version history, training materials and review proposals | Evaluate changes and provide feedback |
| Internal Utkal projects | Founder, with only explicit human delegations | Portfolio oversight, reserved decisions and authorized shared support | Keep project charter, team, work and lifecycle current |
| External member organization | Its own authorized human leader | Deliver only the agreed advisory or managed service | Approve its governing documents, staff decisions, access and applicable commitments |

The Founder approves what Utkal supplies or undertakes. An external organization’s authorized human approves what happens within its organization. One approval cannot impersonate the other. An individual holding both responsibilities records the capacity and scope in which each decision is made.

External enrollment is an association/service relationship, not an entry into the internal human reporting hierarchy. An external employee does not report to Utkal or an AI merely because their employer uses the Blueprint. A separately agreed human management assignment must identify duties, authority and reporting arrangements.

## Proposed participation modes

| Mode | Central visibility and services | Execution authority |
|---|---|---|
| Template adoption | Version information and optional agreed feedback | Organization implements and governs its own instance |
| Guided adoption and training | Agreed assessment inputs, configuration support, exercises and coaching | Local human approves adoption and operational changes |
| Managed operating support | Agreed reports, work coordination, maintenance and specified operational services | Named humans and authorized assistants act only within documented delegated scope |

These are proposed delivery modes, not priced plans or active agreements. A managed service can authorize routine administration without requesting permission for every task, but the permitted actions, systems, limits, duration and escalation points must be explicit. Staff appointments, expenditure, publication and other reserved actions require the relevant human authority.

## Minimum fleet record

Each enrolled instance records a stable organization/project identifier; internal or external status; organizational relationship; named local accountable human; provider-side service owner if applicable; Blueprint version; local charter/agreement versions; adoption decision; participation mode; consented reporting scope; approved tools/integrations; open exceptions; review dates; incident/escalation contact; lifecycle state; and exit/handover requirements.

Retain local project codes within a stable organization namespace so two members can both have a project called BAL without mixing records. Proposed reference form for external instances: organization ID plus local project ID. Allocate an external organization ID only when a real onboarding record is needed; no external organization is enrolled now.

## What central management can do

- Maintain a versioned catalogue of templates, role formats, training and domain-specific examples.
- View agreed metadata: adoption versions, unfilled accountable roles, pending decisions, exceptions and service health.
- Coordinate authorized shared work, produce reports, support human managers and propose improvements.
- Identify drift from the version and local policy the organization actually adopted; distinguish an approved local variation from a missing record or defect.
- Prepare upgrades with impact assessment and support adoption, verification and recovery.
- Provide recurring operating support only where the agreement and assigned human capacity cover it.

Correct implementation requires actual access controls and tested tooling. A document, shared schema or dashboard alone does not enforce governance.

## Boundaries and data

The central registry uses the minimum agreed metadata. Raw guest records, employee performance information, private conversations, contracts and operational datasets remain with the relevant organization unless specifically needed and authorized for a service. Do not place private member data in public Git or reuse it for AI processing, training or another organization by default.

Sharing a Blueprint does not imply sharing credentials, storage or agent memory. Enforce separate project/organization access scopes before introducing integrations. Central AI assistance is supervised by a named provider-side human; local consequential decisions still route to the authorized local human.

Templates and reports must distinguish human decisions, AI recommendations, automated checks and unverified assertions. An automated risk score cannot hire, fire, discipline or replace a human, and payment cannot purchase a favourable quality or editorial finding.

## Change and exception process

Publish a candidate Blueprint version and concrete change log. Assess each instance separately. Record its human adoption decision, migration, verification and rollback plan. No update automatically grants new access, installs a persona or expands authority. Any later automatic maintenance must be a separately approved bounded capability; this draft authorizes none.

Record local exceptions with rationale, affected rule, accountable human, review/expiry date where appropriate and mitigation. Core human authority cannot be overridden by an agent or local declaration. A member can defer an upgrade; any consequence for service compatibility must follow clear agreed terms, not a hidden forced migration.

## Reporting, intervention and exit

Agree the report recipient and cadence with each organization. Report delivery outcomes, unresolved issues, decision needs and evidence limitations. Avoid comparative rankings of individual employees. Internal portfolio reporting follows the Founder’s governance; external management reports follow their service scope.

When a problem emerges, pause only affected actions within existing authority, preserve evidence and notify the responsible humans. Any provider right to suspend its own service must be defined in the agreement; it does not authorize taking control of a member’s business. Keep operational and human decision logs separate from an AI-generated narrative.

On exit, hand over agreed records and open work, revoke service access, end agent assignments and follow agreed retention/deletion obligations. Do not erase attribution or claim an exited organization is still managed. Continuity, export format and responsibility for outstanding actions must be part of onboarding, not invented at departure.

## First implementation proposal

Begin with a manually maintained registry and agreed reports for internal projects. Demonstrate that two instances share a structure while preserving different charters, reporting lines and lifecycle states. Add software only for repeated needs with approved access and testable separation. No central fleet service is running yet.
