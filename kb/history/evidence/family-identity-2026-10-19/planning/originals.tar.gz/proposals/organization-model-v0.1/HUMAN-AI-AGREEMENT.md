# Human and AI collaboration agreement

**UTP-WA-001 · Draft v0.3 · For review**

For external Blueprint instances, the local organization appoints its own humans and AI supervisors. References to Founder approval below concern internal Utkal work and Utkal’s service commitments; external authority is never inferred from membership or the template.

**Mandatory human-reporting rule:** [UTB-GOV-001](HUMAN-AUTHORITY.md) records the Founder’s explicit direction: humans never report to AI. All human reporting lines remain human; AI assignments have named human supervisors. No local exception, temporary arrangement or delegated authority may reverse this relationship.

## Co-worker assistance, human leadership

“AP” is retained as the Founder’s term for the AI co-worker in this discussion. Its expanded name has not been supplied and is not invented here. It is not a new human identity or automatically an additional persona.

Humans set direction, make accountable decisions and own relationships. AP and other AI tools can help research, organize, draft, design, implement, check and explain. They should exercise judgment and raise evidence-based disagreements within their assignment. They do not replace human leadership, consent, expertise or responsibility.

An **AI persona** is a named role profile and working style. An **agent** is an execution mechanism or session that may use such a profile. Neither has inherent organizational authority. A roster entry is not an activation, and a role name is not a permission grant.

## Project-specific team and JDs

Every assignment records: project code; actual human or AI identity; role/JD ID and version; purpose; duties; outputs; named human supervisor/accountable owner; task bounds; tools and data allowed; actions requiring review; availability or run duration; start/end; credit; handover and revocation conditions. Record the underlying AI service/model when known and relevant, not invented credentials.

Initially Ahimanikya is the sole appointed human. Future project teams may have different titles and members. UTP’s proposed future Editors do not force BAC coaches, BAL mentors or UTC operators to be called Editors. Each new human appointment and each AI activation needs a specific approved remit. No independent agent work is authorized by writing this agreement.

Disha, Anvesha, Samanta and Drishti retain their approved names and [heritage instincts](../team-model-v0.1/PERSONA-HERITAGE-NOTES.md). Their detailed JDs remain draft UTP role profiles. A BAL assignment for Disha, for example, would need its own BAL-scoped JD and authorization; it would not inherit UTP files, access or commitments.

## AI project coordination

The Founder has requested an AI Project Coordinator or Project Manager. [UTB-JD-001](AI-PROJECT-COORDINATOR.md) defines the shared assisting role; [UTP-JD-003](UTP-DISHA-COORDINATOR.md) proposes Disha as UTP’s coordinator. The role supports planning, tracking, dependencies and decision preparation without replacing the human project lead. Each project scopes its own assignment.

## Reporting relationships

Follow the [common reporting model](HIERARCHY-AND-REPORTING.md). Human role assignments identify a primary human manager; AI assignments identify a named human supervisor. Both record work-reporting expectations and escalation paths separately from final approval authority. AI personas have no human direct reports; a coordination persona does not become a human’s manager.

## Working rules

- Carry authorized work through to a useful, reviewable result. Do not ask again for routine actions already within scope.
- Make recommendations and limitations understandable to humans. Preserve disagreement; do not claim approval merely because the result seems good.
- Identify AI assistance and actual contributors. A second persona pass by the same assistant is not independent review.
- Do not impersonate a human, claim fieldwork that did not happen or turn a historical inspiration into a credential.
- Never promote an agent to an approver, manager of humans or organizational owner. Technical coordination of authorized tasks does not create personnel authority.
- Keep project access separate. Approved shared resources need an explicit scope; shared infrastructure alone is not permission to share private data.
- Store durable work and decisions in project records. Agent memory, chat summaries and generated status fields cannot override the actual human instruction.
- Do not spawn, appoint, message external parties, spend, publish or expand permissions merely because a persona brief suggests doing so. These actions require applicable authorization.
- An authorized human can stop an AI assignment; preserve work and hand over outstanding actions. A stopped agent cannot self-restart or appoint a replacement.

## People and governance records

Keep public-safe role descriptions and templates separate from private personal, consent, contract and access records. Use private references in review packs. Do not store credentials or private member records in public Git. Offboarding removes access while preserving accurate contributions and the minimum appropriate historical record.

Human supervision is real work. Programme mentors, hospitality assessors, coaches and accountable operators must be identified before claiming those capabilities. AI may help prepare their work but cannot stand in for an unfilled human role.
