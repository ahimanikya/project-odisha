# Current projects and codes · 15 October 2026

**Project Odisha (POD) is the new name of Utkal Project, not a separate related project.**

| Current code | Current name | Previous code |
|---|---|---|
| POD | Project Odisha | UTP |
| ODC | Odisha Collective | UTC |
| ODU | Odisha Unbound | UTU |
| ODB | Odisha Blueprint | UTB |
| BAL | Bhubaneswar Alpha Lab | BAL |
| BAC | Bhubaneswar Athletic Club | BAC |

ODC retains its independent lifecycle; BAL/BAC retain their intended ODC placement. ODU placement remains open. These naming changes do not alter legal relationships. Existing record IDs remain resolvable; future prefixes use the current codes.

The earlier register below is preserved as a historical naming baseline and is superseded by the table above.

---

# Projects and identifiers

**UTP-REG-001 · Record v0.9 · Prefixes and record-type labels agreed; operating details remain draft**

## Project identities

| Code | Project | Relationship | Current observed work |
|---|---|---|---|
| UTB | Utkal Blueprint | Distinct Blueprint development workstream; UTP stewardship context | Design and build planning; own governance instance pending |
| UTP | Utkal Project | Master coordination project; own knowledge/community mission | Planning, knowledge preparation and existing draft product records |
| UTC | Utkal Collective | Independent project closely associated with UTP; master coordination context | Hospitality planning plus future farm resorts and member initiatives |
| UTU | Utkal Unbound | Distinct project identity named by Founder; exact coordination placement open | Concept; traveller-facing role previously suggested, not settled |
| BAC | Bhubaneswar Athletic Club | Intended part of UTC; independent project lifecycle | Concept; sports and operating model open |
| BAL | Bhubaneswar Alpha Lab | Intended part of UTC; independent project lifecycle | Concept; proposed adaptation of Bangalore Alpha Lab name; camps/incubation |

This is an organizational registry, not a legal entity or live-service register. Each project has Ahimanikya as the initial accountable human; no further appointments are inferred. A brand and a project can coincide without creating another company. Farm resorts have no separate project code yet; assign one when an actual bounded project is defined.

## Shared Blueprint namespace

**UTB — Utkal Blueprint** identifies the reusable template, shared central-governance specifications and offering design. The Founder has now explicitly distinguished building the Blueprint from building UTP, so UTB also identifies its own development workstream and backlog. It is not a newly incorporated entity or an extra adopter inserted into the UTP → UTC → UTU sequence. UTP remains the master project and current stewardship home.

Use **UTB-TPL-001** for the shared project template. Project-specific charters, team assignments, decisions and work retain their own prefixes, such as **UTP-CHR-001** or **UTC-WORK-001**. An internal Utkal reporting chart remains a UTP record rather than becoming a universal member hierarchy.

The Founder accepted UTB and the following record labels after the naming proposal with “That sounds good”. The accepted convention is recorded separately from approval of any document contents.

## Prefix revision

The Founder requested a three-letter prefix for Utkal Project. The current code is **UTP**, replacing **UP**. Current references use UTP; historical snapshots retain their original spelling. The structured register maps each earlier UP record ID to its UTP equivalent. The Founder subsequently requested the same three-letter treatment for the other two initial projects: **UTC** replaces **UC** for Utkal Collective, and **UTU** replaces **UU** for Utkal Unbound. BAL and BAC already use three letters. These identifier changes create no new requirement or approval; historical aliases remain resolvable.

## Identifier convention

Agreed form: **PREFIX-TYPE-NNN**, for example `UTB-GOV-008`, `UTC-REQ-001`, `BAL-WORK-001` or `BAC-JD-001`.

The owning project or shared Blueprint prefix comes first. Type describes the record: `CHR` charter, `GOV` governance proposal/policy, `WA` working agreement, `TPL` template, `REG` register, `JD` role/job description, `REQ` requirement, `WORK` task, `DEC` actual decision or direction, `REV` review, `REL` release/application. A GOV ID is not proof of adoption; DEC records must identify whether they capture actual direction or a pending proposal.

Numbers are unique within each prefix/type, never reused or silently reassigned. Use at least three digits; add digits as needed. Keep versions separate from IDs. A renamed project retains its stable code unless an explicit migration is approved. A cross-project task uses the initiating project’s ID and links the other project’s related record rather than ambiguously sharing one ID. When an item moves, retain its original ID and a transfer reference.

## Legacy aliases and preservation

| Earlier ID | Project-based reference | Treatment |
|---|---|---|
| TM-01 … TM-07 | UTP-GOV-001 … UTP-GOV-007 | Same seven draft team-model proposals; identifiers do not make them approved |
| R-01 … R-12 | UTP-JD-001 … UTP-JD-012 | Aliases for the earlier UTP draft role profiles; personal assignments still need their own records |
| HA-001 … HA-020 | UTC-REQ-001 … UTC-REQ-020 | Proposed aliases for hospitality requirements; preserved PRD v0.1.0 remains unchanged |
| HA-D01 … HA-D07 | UTC-DEC-001 … UTC-DEC-007 | Existing hospitality direction records; map without rewriting historical quotations |
| HA-P01 … HA-P08 | UTC-GOV-001 … UTC-GOV-008 | Existing hospitality proposals; no authority inferred |

The old team overview is preserved before its visible TM references are updated. Historical snapshots retain original IDs. Existing role files and hospitality PRD are not bulk-renumbered in this task; the alias register bridges them until a reviewed revision. The structured registry lists every individual alias to avoid range ambiguity.

New organizational records begin at UTB-GOV-008, avoiding the seven legacy proposal IDs. Each future project tracks its own allocation. An ID allocation is a reference convention, not a project approval, legal status or automation trigger.

## Typed members and role identity

The [proposed member model](MEMBER-TYPES.md) specifies an explicit `kind: human | persona` independent of role, reporting and authority. The field design remains for review; the human-only reporting rule is already Founder-directed. A shared role profile is a UTB record; an actual project assignment is scoped to its project.

## Agreed record types

| Label | Record |
|---|---|
| CHR | Charter |
| GOV | Governance |
| JD | Job description |
| WA | Working agreement |
| REQ | Requirement |
| WORK | Work item |
| DEC | Decision |
| REV | Review |
| REL | Release |
| TPL | Template |
| REG | Register |

Member-organization codes will be allocated when needed. No separate persona-prefix scheme is introduced.
