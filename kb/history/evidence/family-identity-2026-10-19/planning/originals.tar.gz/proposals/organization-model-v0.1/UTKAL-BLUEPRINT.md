# Utkal Blueprint

**Utkal Blueprint — created by Ahimanikya Satapathy, Founder & Editor-in-Chief of Utkal Project.**

See the [authorship and discussion-before-reuse direction](MODEL-AUTHORSHIP.md).

**UTB-TPL-002 · Product definition draft v0.9 · 27 September 2026**

**An organization operating model for humans and AI working together under human leadership.**

The Founder has named the common template **Utkal Blueprint** and directed that it support central governance, extension to member organizations, and an offering combining the operating model with training. The name and direction are recorded; the detailed service design remains for review. This replaces the earlier proposed template name “Living Knowledge Studio”. Name, trademark and domain availability have not been checked.

**Record prefix: UTB.** Shared Blueprint definitions use this namespace; each adopter uses its own project prefix for its local governing records. The prefix does not create a separate legal entity.

## What the Blueprint contains

| Layer | Purpose | Concrete outputs |
|---|---|---|
| Organization design | Establish structure and accountable humans | Charter, organization hierarchy, human reporting lines, project relationships |
| Human–AI collaboration | Define how people and AI contribute | Human and AI JDs, named supervisors, tool/data boundaries, working agreements |
| Governance | Make authority and decisions traceable | Decision rights, human approval gates, escalation, delegation and change records |
| Delivery | Turn agreed work into reviewable results | Briefs, work records, evidence, review, release/application and learning records |
| Central oversight | Coordinate participating instances | Registry, version/adoption status, agreed management reports, exceptions and upgrade proposals |
| Enablement | Help people use the model in practice | Training, guided setup, supervised exercises, coaching and handover |

The common structure is shared. Each project or organization maintains its own governing contents, roster, work, lifecycle and adopted version. The Blueprint is a reusable organizational asset with its own [UTB development workstream](../../subprojects/utkal-blueprint/README.md). It does not create another legal entity or require a particular AI vendor, repository or hosting service.

## Where it applies

1. **Our organization:** UTP will adopt first, followed by UTC and UTU. BAL and BAC are intended later adopters and are currently deferred. Each will have its own governed instance. The Founder retains the internal final gate.
2. **Member organizations:** an independent organization can adopt the Blueprint and, if agreed, receive training or managed operating support. Its authorized human leadership retains its own authority. Adoption does not make it an internal Utkal subsidiary.
3. **Other teams:** potential later users can be considered through an approved offering scope. No general market launch or customer demand is claimed.

Existing hospitality membership does not automatically enroll an organization in Blueprint services, approve data sharing, delegate management or create new charges. Scope, terms and human authority are explicit for each relationship.

## Central governance and fleet management

“Fleet” means the set of enrolled project/organization instances and, where authorized, their AI assignments. The common template makes their structure and status comparable. A registry and status report come first; an automated management platform can follow if actual operating needs justify it.

Central oversight can maintain standards, offer training, track adoption and exceptions, coordinate shared work and provide agreed operational support. It does not inherently give the provider control over every member’s staff, money, systems or data. See [central governance](CENTRAL-GOVERNANCE.md) for the authority model.

## Offering and delivery

The proposed offering has three components: **adopt the operating model, train the team, and optionally support ongoing operations**. These can be scoped separately. The intended outcome is clearer accountability and more effective human–AI work, to be tested through real work rather than assumed from the template or training attendance.

The [offering and training design](OFFERING-AND-TRAINING.md) defines suggested deliverables, exercises, acceptance and stages. Utkal Collective is a proposed home for commercial delivery; BAL could be a future training delivery partner within the portfolio, but its start is deferred and initial adoption must not depend on it. Neither assignment, staffing nor price is decided by this draft. UTP remains the current planning home for Blueprint stewardship.

## Separate development and adoption

The Founder directed that we build both UTP and the Blueprint. UTB owns reusable template/package development, validation design, documentation and release preparation. UTP owns its actual knowledge/website delivery and its own adoption. The [UTB backlog](../../subprojects/utkal-blueprint/BACKLOG.json) tracks reusable work; UTP’s adoption decision and delivery evidence remain UTP records.

The proposed [member-type design](MEMBER-TYPES.md) separates human/AI identity, role and authority. Its implementation remains pending.

## Build sequence

Founder-directed internal adoption order: **Utkal Project → Utkal Collective → Utkal Unbound**. **BAL and BAC start later.** See [the adoption plan](ADOPTION-PLAN.md).

Within that order, the proposed method is to review and adopt a concrete UTP instance, exercise it on bounded work and refine from evidence before UTC and UTU adopt their own instances. External member pilots, repeatable training, managed support and automation remain later proposals, with no launch date.

The same blueprint structure must work across instances while their local decisions remain independent. Each stage needs a human owner, a concrete deliverable and evidence of usefulness. Free founding hospitality membership is a separate commercial policy and does not set Blueprint pricing.

## Current status

The deliverable is a written model and offering proposal. No agents, fleet dashboard, automatic policy updates, training sessions, certifications, managed-service agreements or external enrollments have been activated. The historical drafts and current review manifest preserve how the model evolved.
