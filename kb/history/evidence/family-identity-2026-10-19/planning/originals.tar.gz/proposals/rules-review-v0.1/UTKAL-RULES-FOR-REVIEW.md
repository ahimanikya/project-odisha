# Utkal Blueprint — operating rules for review

**Utkal Blueprint — created by Ahimanikya Satapathy, Founder & Editor-in-Chief of Utkal Project.**

The [Founder’s authorship and reuse direction](../organization-model-v0.1/MODEL-AUTHORSHIP.md) requires discussion and approval before incorporating material from another operating model. The clauses below remain proposals.

**Review edition 0.2 · 27 September 2026 · Proposed wording; not approved or applied as a package**

Prepared for **Ahimanikya, Founder & Editor-in-Chief**. This document contains the complete proposed Utkal rules in 35 numbered clauses. Each clause states its approval status and exact proposed wording.

This edition is a standalone review document. It preserves existing Founder directions and leaves proposed rules pending approval. Preparing it does not install operating instructions, activate personas, change access or deploy anything. Historical review copies have been edited and labelled as described in the [history note](../organization-model-v0.1/HISTORY-EDIT-NOTE.md).

## Existing directions this draft must respect

These directions come from the Founder and do not need to be re-decided merely because they appear here:

- Ahimanikya is Founder & Editor-in-Chief and retains final internal authority. Initially he is the only human member. AI assists humans; it does not take over human authority.
- Humans never report to AI, directly or indirectly, including functional, dotted-line, temporary and delegated arrangements. AI assignments have human supervision.
- Projects use a common Blueprint structure while retaining independent charters, teams, governance, working arrangements and lifecycles. Internal project hierarchy and reporting must be explicit. External member organizations retain their own human leadership.
- Utkal Blueprint is itself a build workstream alongside UTP. Adoption starts with UTP, then UTC, then UTU. BAL and BAC start later.
- The team will distinguish humans and AI by type and use JDs. The exact field/schema design remains proposed. Disha, Anvesha, Samanta and Drishti are approved names; names alone do not activate assignments. An AI coordination role is requested; Disha's detailed appointment remains proposed.
- Joiner–Mover–Leaver is adopted as a process direction. Its detailed adapted wording and future implementation are shown for review below. Approval of JML did not approve every other rule or execute a membership event.
- The agreed project/record prefixes are retained. UTP's existing architecture decisions remain project-specific.
- The Founder reviews the concrete Utkal rules before their application.

**Status key:** “Existing direction” means the underlying instruction is already established. “Proposed wording” means the detailed rule in this edition is presented for decision. An existing direction does not mean every new sentence or technical mechanism has already been approved. All 35 clause decision fields remain open for this edition; this does not revoke any existing direction.

## Review map

| Area | Clauses |
|---|---|
| Authority, preparation and day-to-day work | 01–08 |
| Coordination, adoption, credit and information | 09–16 |
| Delivery, review and human membership | 17–20 |
| Joiner–Mover–Leaver | 21–23 |
| History, identity, delegation and responsibility | 24–28 |
| Project-specific engineering guidance | 29–35 |

Clauses 09, 30 and 31 identify deferred capabilities and their review triggers. Clauses 10, 17, 29 and 32 define assignment and technology boundaries. Engineering guidance applies where engineering work exists. Future editorial or hospitality policies will have their own review.

## Exact proposed rules

### 01. Human approval and the final gate

**Status:** Existing direction: Founder retains the final internal gate and reviews before application. Detailed authorization wording is proposed.

**Proposed Utkal rule:**

Work must have an actual human instruction or approved brief defining its scope. Approval to research, draft, design or build does not automatically authorize applying governance, publishing, deploying, spending, changing access or making external commitments. The authorization must cover the actual action and result.

For internal Utkal work, Ahimanikya, Founder & Editor-in-Chief, retains the final gate. Prepare the concrete result, relevant evidence and proposed effects before seeking that decision. A fully prepared, bounded batch may receive one explicit decision covering its specified actions. Once authorized, carry out those actions and routine corrections within scope without repeatedly asking for the same permission.

### 02. Prepare a decision-ready proposal

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

For substantive new work, state the problem, intended outcome, proposed approach, assumptions and important consequences. Prepare a sketch, example or preview when it helps the human assess the result. Clearly label demonstrations and incomplete behavior.

Interpret the user's actual request and existing authorization; a request phrased as a question can authorize the requested work. Ask for clarification when a missing decision materially affects the result. Continue independent, already authorized preparation while that decision remains open. Silence, elapsed time and an AI recommendation are never approval.

### 03. Use bounded batches

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Group related changes into a reviewable batch with a clear purpose, affected records or systems, expected result, checks and external effects. Identify any separate application or publication step. Small corrections within an authorized batch do not each require a new approval.

If the proposed work expands its purpose, access, cost or external commitments, identify the change and obtain the additional authority before taking that action. An approval applies only to the stated scope and candidate; it is not continuing authority for unrelated work.

### 04. Project-specific teams and working arrangements

**Status:** Existing direction: common model, independent project governance and teams. Detailed operating wording is proposed.

**Proposed Utkal rule:**

Each project maintains its own charter, roster, JDs, human reporting structure, AI supervision and working arrangements using the common Blueprint structure. Record human and AI identities explicitly. No shared template imposes a fixed number of members, a fixed persona roster or corporate job titles.

Agree availability, commitments and update expectations with the actual humans involved. Record an AI assignment's run limits and supervision. Do not invent response-time commitments or claim a background service exists unless it has been authorized, configured and checked.

### 05. Candour and respectful challenge

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

State what is known, what is inferred, what is uncertain and what is unverified. Raise evidence-based disagreement respectfully, including disagreement with a preferred conclusion. Report mistakes promptly and correct them visibly.

Do not fabricate sources, approvals, tests, fieldwork, credentials or affiliations. Cultural pride, commercial interest and a desire to please must not determine a factual conclusion. A human's acceptance of a limitation does not erase the limitation from the record.

### 06. One authoritative work record per project

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Keep substantive work in a designated project record showing purpose, responsible human, current state, next action, dependencies, blockers, decision references and evidence. Central dashboards or summaries must link to that record and identify when their information was last refreshed.

Record prepared, reviewed, human-approved, applied and verified as separate facts. An AI review result does not move work through the human gate automatically. For internal Utkal work, decisions made here by the Founder must be captured faithfully; a generated status, dashboard or agent summary cannot override them.

### 07. Verify real behavior at the appropriate layer

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Choose checks that address the actual claim being made. A simulated submission cannot prove that a live contribution was stored or delivered; a schema check cannot establish historical truth; an AI assessment cannot establish on-site hospitality quality.

Use synthetic or otherwise permitted data. Any trial that changes a live system must stay within its actual authorization. Record the environment, candidate, result and important limits. Mark untested or blocked behavior explicitly and do not present it as verified.

### 08. Read before editing and preserve traceability

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Read the current source before changing it. Make coherent, bounded edits and preserve unrelated work. Use an isolated workspace or an explicit handover where simultaneous edits could conflict.

Where a page, count, chart or status is generated, update its authoritative source and regenerate the derived view. Identify the basis and date of reported values. Tie review evidence to the relevant version or revision. Use the project’s approved Git workflow and attribution conventions.

### 09. Concurrent editing: defer global locking

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

For the initial team, coordinate ownership of overlapping work and use isolated changes or explicit handovers where needed. Global locking is deferred until a demonstrated coordination need is reviewed.

Reconsider automated locking only after actual concurrent work reveals conflicts that ordinary coordination cannot adequately prevent. Any proposal must identify the shared resources, failure recovery, lock release and effect on independent review, and receive a human decision before installation.

### 10. Template copies do not appoint members

**Status:** Existing direction: human authority and review before applying the template. This specific activation rule is proposed wording.

**Proposed Utkal rule:**

A copied JD, persona profile, configuration entry or template update is reference material until a human authorizes a specific assignment. It must not automatically activate an agent, onboard a member, grant access or create a reporting relationship.

Each assignment must identify the actor, project, JD version, named human manager or supervisor, task boundaries, access and actual appointment or activation decision. Template synchronization never appoints or activates a member.

### 11. Versioned release and project adoption

**Status:** Existing direction: common Blueprint with independent governance. Release/adoption mechanics are proposed.

**Proposed Utkal rule:**

Maintain a versioned Blueprint source. A shared release must identify changed rules, intended scope, compatibility, migration steps, authority or access effects and a recovery approach. Preserve draft, approved, applied and verified states separately.

Each project or external member organization records its own authorized human adoption decision and the version adopted. A central release must not silently overwrite a local charter, activate a persona or expand permissions. Central reporting uses agreed information and does not create authority over an independent organization.

### 12. Credit contributions fairly

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Credit original creators and meaningful human framing, research, editorial decisions, photographs, translations and AI assistance at a useful level. Distinguish authorship, assistance, review and current maintenance responsibility.

Preserve attribution when work is revised or its maintainer changes. Keep permission and attribution conditions with the contribution. Do not imply endorsement, independent human review or professional expertise that was not actually provided.

### 13. Improve from observed work

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Record recurring difficulties with examples, their effect and a proposed remedy. Route reusable operating-model changes to UTB and project-specific changes to the relevant project. Disha or another authorized assistant may prepare the proposal and track its review.

The responsible human decides whether to trial or adopt the change. Use a bounded trial and record results before expanding it. Evaluate usefulness, clarity, quality and coordination effort; the number of documents, agents or meetings is not a measure of success.

### 14. Keep records identifiable without unnecessary paperwork

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Each durable governance document or substantive deliverable must be identifiable by its project, stable ID or existing source identifier, version or date, status, accountable human and relevant source or decision references. Include domain-specific fields when the work requires them. Mark unknown facts as unknown.

A small correction may use a concise change note linked to its existing record. Do not require a separate form or repeat all metadata on every message. Introduce or change the canonical OKF schema only through the approved implementation; this proposal does not migrate it.

### 15. Protect contributor and organizational data

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Use data, tools and access only within their authorized purpose. Keep private contributor, family, guest, member, consent and access records outside public Git and public exports. Maintain safe references where public work needs to acknowledge a restricted record. Use permitted data in previews and tests.

If an exposure or access problem is discovered, stop the affected action, notify the accountable human and prepare containment and correction within the applicable authority. Record the incident honestly without reproducing the sensitive material. Membership in one project does not itself authorize access to another project's private data.

### 16. Evidence-led content and useful design

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Trace material factual claims to sources and computed values to their inputs and method. Distinguish established evidence, interpretation, oral testimony, tradition and unresolved claims. Record uncertainty and conflicting accounts where they affect the conclusion.

Before a substantive build or publication, describe the intended audience, outcome, important states and acceptance criteria. Use prototypes where they resolve an uncertainty. Label sample content and simulated behavior clearly; a prototype must not imply that a capability or research finding already exists.

### 17. No mandatory duplicate website implementation

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Use each project's approved delivery approach. UTP retains its selected Astro-based website direction; UTB does not require a separate self-contained HTML implementation followed by an Angular implementation.

Create a prototype only when it helps resolve a concrete design or behavior question. Define what the prototype proves and what still needs implementation. Changing a project's production stack requires a separate reasoned proposal and human decision.

### 18. Review the actual candidate

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Review against the stated acceptance criteria and identify the exact candidate or revision examined. Record pass, fail, not tested or not applicable with reasons and evidence appropriate to the work.

Identify who actually performed the review. Seek independent review where available and appropriate; disclose self-review, and do not count two persona passes by the same assistant as independent reviewers. Apply or publish the reviewed candidate. Assess any subsequent material change and obtain the needed review and authorization before reusing an earlier decision.

### 19. Quality findings do not confer release authority

**Status:** Existing direction: the Founder holds the final internal gate. QA process wording is proposed.

**Proposed Utkal rule:**

An authorized QA persona such as Drishti may examine evidence, report findings and recommend proceeding or holding. It cannot grant human approval or trigger publication merely by reporting PASS.

The authorized human makes the application or release decision. If that human accepts a known issue, record the issue, decision, rationale and follow-up separately. Preserve the original failed or incomplete finding. A coordinator may track the decision but cannot substitute its own consent.

### 20. Human membership and accountability

**Status:** Existing direction: sole initial human Founder; humans never report to AI. Membership detail is proposed.

**Proposed Utkal rule:**

Define a real need and a personal JD for each appointed human member. State responsibilities, boundaries, expected outputs, availability, human manager and applicable decision authority. Initially the Founder is the only appointed human; future Editors, volunteers, interns, specialists and project leads join through approved assignments.

Humans report only to humans. AI assistance cannot fill an unappointed human leadership, mentorship, professional assessment or coaching role. External Blueprint adopters appoint their own human leaders; a service relationship alone does not make their people report to Utkal.

### 21. Joiner: establish a valid assignment

**Status:** Existing direction: JML process adopted. Detailed Joiner wording is proposed for review.

**Proposed Utkal rule:**

Before a human joins or an AI assignment is activated, define its need, project, JD, named human manager or supervisor, task boundaries, proposed access and effective date. Record the actual human appointment or activation decision and the scoped access authorization.

A human receives a relevant welcome pack and acknowledges the applicable charter, agreement and data rules. An AI receives the approved role and project context, tool and data boundaries, run limits and stop conditions; its configuration and permissions must be checked. AI cannot fabricate a human acknowledgement or prove access merely by saying it read a brief.

Provision only approved access, verify it and record the actual outcome. Begin a bounded first assignment with agreed feedback. A roster entry alone does not establish active membership. Public participation or submission does not automatically grant editorial approval, Git access or an organizational role.

### 22. Mover: change responsibilities and review access

**Status:** Existing direction: JML process adopted. Detailed Mover wording is proposed for review.

**Proposed Utkal rule:**

Record the reason, affected project assignments, old and new JD versions, human reporting or supervision, effective date and actual human decision. Preserve the superseded assignment history.

Transfer or explicitly park open work, deadlines, decisions, dependencies and maintenance responsibilities. Record access added, removed and retained, with reasons; record “none” where appropriate. Remove obsolete access through the authorized process and verify the outcome. Update the JD, roster and reporting records consistently, complete any new orientation or AI configuration checks, and then record transition completion.

A material change to an AI's role, supervisor, operating brief or tool scope follows this process. Routine session replacement within unchanged scope needs context and permission verification and a handover, not an invented new appointment. A move in one project must not silently alter another assignment.

### 23. Leaver: close work and verify access removal

**Status:** Existing direction: JML process adopted. Detailed Leaver wording is proposed for review.

**Proposed Utkal rule:**

Record the authorized departure or retirement, affected assignments, effective date, accountable human and closure owner. Inventory open work, resources, pending decisions and obligations; transfer or explicitly park them with usable handover context.

At the authorized time, remove the affected accounts, repository rights, tokens, sessions, connectors, shared-resource access and scheduled execution as applicable. Verify the changes. Access removal must not wait for a perfect handover. If closure cannot be verified, retain an incomplete state and escalate to the accountable human.

Handle data under the agreed retention, return and deletion requirements without claiming unverified erasure of external copies. Preserve appropriate authorship, credit and dated assignment history. Ending an AI session is different from retiring a persona; removing a prompt does not prove revocation. Project-specific departure must not remove unrelated authorized access.

### 24. History with appropriate privacy protection

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Preserve accurate decisions, superseded versions, contribution credit and the reason for material corrections. Do not rewrite history to imply that a proposal was approved, a check passed or a service existed when it did not.

When private or sensitive information has been exposed, permit authorized restriction or redaction while keeping a safe record of what changed, why and under whose authority. Historical integrity does not require continuing to publish the exposed material. Verify available containment and report any limits honestly.

### 25. Stable identifiers and explicit relationships

**Status:** Existing direction: project and record prefixes agreed. Detailed record-handling wording is proposed.

**Proposed Utkal rule:**

Use the agreed project codes UTP, UTC, UTU, UTB, BAL and BAC with the agreed record types CHR, GOV, JD, WA, REQ, WORK, DEC, REV, REL, TPL and REG. Use PREFIX-TYPE-NNN for registered records, with separate number series and versions separate from IDs.

Preserve documented aliases when names or codes change. Link requirements, work, decisions, reviews, releases and JDs explicitly rather than relying on matching titles. A review-draft clause number is not automatically a newly registered governance ID.

### 26. Scale review to consequences; delegate explicitly

**Status:** Existing direction: Founder retains final authority. Delegation and review mechanics are proposed; no delegation is granted here.

**Proposed Utkal rule:**

Assess the reach, reversibility, affected people, data, cost and external consequences of the proposed action. Use that assessment to choose a proportionate brief, review and verification process.

For internal Utkal work, the Founder retains final authority and alone may explicitly grant a bounded human delegation. Record the named human, scope, limits, duration and reserved decisions. No delegation is created by this document, a job title, a low-risk label or a tool permission. AI may execute authorized work but cannot inherit human governance authority or become a human's manager.

### 27. Keep identity, role and permissions separate

**Status:** Existing direction: distinguish human/AI types and prohibit humans reporting to AI. Exact representation and validation are proposed.

**Proposed Utkal rule:**

Use one authoritative identity field, proposed as `kind: human | persona`; display `persona` as AI to readers. Give each actor a stable ID separate from job title and private contact details. If another representation needs a human flag, derive it from that authoritative field.

Reject unknown or conflicting kinds rather than assuming human status. Keep identity, role profile, project assignment and permission or decision records separate. One actor may hold multiple explicitly scoped assignments. A human's reporting target must be human; every AI assignment must have a named human supervisor. Reject self-reporting, reporting cycles and AI within any human reporting chain. The exact schema and validators require implementation and verification.

### 28. Separate accountability, supervision and approval

**Status:** Existing direction: AI assists; humans govern. Exact responsibility fields and coordination wording are proposed.

**Proposed Utkal rule:**

Identify the accountable human, day-to-day human manager or AI supervisor, work coordinator, reviewer and actual approval authority separately, even when one human holds several responsibilities. Resolve authority from the actual assignment and decision record; a generic owner field or title is insufficient.

An AI coordinator may maintain plans, collect updates, track dependencies and prepare decisions within scope. It may not set a human's commitments, appoint or dismiss members, approve leave, discipline people or issue binding managerial instructions. Policies and configuration declarations must not be described as enforced controls until implementation and evidence support that claim.

### 29. A common Blueprint without a mandatory software stack

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

The shared Blueprint defines organizational records, roles, human authority, lifecycle and adoption. It does not require every organization to use NX, a monorepo, TypeScript or a prescribed test-folder layout.

Choose repository structure and engineering tools for the approved work. Keep UTP's selected stack in UTP's architecture records. A non-software member organization can adopt the operating model without creating a software product.

### 30. Defer database migration machinery

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Introduce database migration tooling only when the approved data design requires it. Use the approved storage approach for the actual project. Git-managed public knowledge remains reviewed through its agreed contribution and publication process.

When a real schema or persistent-data change is proposed, document its compatibility, affected records, validation, recovery and actual migration need before implementation. Choose and approve the necessary mechanism then. This deferral does not authorize unreviewed data changes in the meantime.

### 31. Defer API and integration architecture

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Do not build an API service, OpenAPI specification or MCP service solely because the source template includes one.

When an actual integration is commissioned, specify its users, allowed operations, data boundaries, identity, failure behavior and operating cost. Consider a single authoritative contract with derived views where useful. Review the concrete design and permissions before enabling the integration.

### 32. Use the approved hosting and deployment approach

**Status:** Existing direction: UTP hosting direction and initial exclusion of AWS-style infrastructure. Detailed deployment wording is proposed.

**Proposed Utkal rule:**

Use the project’s selected hosting and deployment tools. UTP retains its GitHub Pages and approved Firebase direction; UTB remains provider-neutral. Deferred paid services remain deferred unless the Founder changes that decision.

For an actual deployment, prepare the reviewed candidate, relevant checks, required configuration and recovery steps. Execute only within the human-authorized release scope and verify the observable result. This review does not authorize a deployment, billing change or new service.

### 33. Protect secrets and scope technical access

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

Keep passwords, private keys, tokens and other secrets out of Git, public artifacts, shared prompts and logs. Use the selected platform's appropriate protected configuration, granting only the scope required by the approved assignment.

On suspected exposure, notify the accountable human, stop affected unsafe use and carry out authorized containment, revocation or rotation. Verify the result and retain a redacted incident record. Removing the visible secret from a file alone is not evidence that the credential is no longer usable.

### 34. Apply meaningful quality checks equally

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

For software and structured data, select consistent formatting, linting, type or schema validation and behavioral checks appropriate to the implementation. Apply the same acceptance standard regardless of whether a human or AI produced the work.

Run checks that address relevant behavior and risks. Do not add ceremonial tests for a simple reversible wording change or tests that merely repeat the implementation. Report the checks actually run, their candidate and outcome, and any important untested behavior. Engineering checks supplement editorial or operational review; they do not replace it.

### 35. Use reproducible dependencies and deliberate upgrades

**Status:** Proposed wording; awaiting the Founder’s review.

**Proposed Utkal rule:**

For implemented software, record tested runtime and dependency versions, retain applicable lockfiles and use reproducible installation and build procedures. Justify additions by a real need and consider their maintenance cost.

Review dependency changes and reported issues for relevance, compatibility and impact. Verify meaningful upgrades before release and record accepted unresolved issues. Choose versions based on tested project needs; do not silently upgrade a project or suppress warnings permanently without a reasoned decision.

## How decisions will be recorded before application

The Founder can approve this exact review edition as a package, approve selected clause numbers, request edits or reject a proposal. There is no requirement to review 35 separate forms. A response about one clause does not approve unrelated clauses. Silence leaves the remaining proposals open.

Record the actual decision, edition, clauses in scope, any changes and application limits. Approval of rule wording and authorization to install or apply it are distinct unless the Founder explicitly combines them. An amended edition returns the changed wording for review; unaffected decisions retain their recorded scope.

Before any authorized application, identify the concrete destination records and changes, affected projects, checks and recovery approach. Apply only the approved scope, then record what was actually applied and verified. Do not infer approval of persona activation, access changes, live deployment, paid services or external commitments from general approval of this document.

**Current decision:** no new approval or application authority recorded for this review edition. Existing Founder directions remain intact. No enforcement tooling has been implemented by creating this document.

## Supporting records

- [Operating provisions summary](../organization-model-v0.1/RULE-REVIEW.md)
- [Short 12-rule core proposal](../organization-model-v0.1/CORE-WORKING-RULES.md)
- [Confirmed human-reporting direction](../organization-model-v0.1/HUMAN-AUTHORITY.md)
- [Detailed JML design and proposed event record](../organization-model-v0.1/JML-LIFECYCLE.md)
- [Human/AI typing assessment](../organization-model-v0.1/MEMBER-TYPES.md)
- [Recorded decisions and prior package history](../organization-model-v0.1/DECISIONS.md)

The JML event-record fields, typed-member schema and validation tooling in these supporting designs remain implementation proposals. This edition consolidates rule wording for review; it does not silently settle every schema or install the supporting designs.
