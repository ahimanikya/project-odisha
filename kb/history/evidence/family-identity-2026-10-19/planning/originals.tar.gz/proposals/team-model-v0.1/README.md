# Utkala · Odisha — proposed human and AI team model

**UTP team proposal v0.1 · Review index revision v0.2 · 27 September 2026 · FOR REVIEW ONLY · NOT ADOPTED**

Prepared at Ahimanikya’s request for Utkal. This package authorizes nothing and installs nothing. It sits outside the canonical OKF collection, project instructions, persona configuration and deployment machinery. Statements below describe a proposed future operating model. The user’s current direction—review before application and sole final authority—already governs this task.

The [organization and governance model](../organization-model-v0.1/README.md) now defines the broader multi-project design: the same model and structure, with independent project governance. This packet is a draft UTP-specific team profile, not a charter imposed on UTC, UTU, BAC or BAL. The [prior review index](history/team-overview-v0.1-before-project-prefixes.md) preserves the earlier TM references; current IDs use the UTP project prefix. No pending proposal is approved by renumbering it.

## Recommendation

Build a small **editorial, research and engineering team**, with **Ahimanikya as Founder & Editor-in-Chief, the only human member for now and sole final decision-maker**. Four proposed AI personas contribute expertise; future human Editors may join only when he appoints them. Their recommendations and review findings inform his decisions. No role inherits approval authority from its title, membership, Git access or a template file.

Use clear roles, a shared work record, explicit requirements, evidence-based checks and contribution credit. The delivery process covers knowledge publication, heritage research, community participation and the website. Use two recurring human decisions: approve the scope of work, then approve the concrete result for application or publication. A ready, fully reviewed document batch can combine those decisions in one explicit approval. Routine work and repairs inside an approved scope do not require repeated permission.

**“Everything happens here”** is interpreted as: this Utkala · Odisha project conversation is the decision and coordination home. Files preserve the durable record. Git and any future services execute only approved work; another conversation, contributor comment or automated result cannot silently authorize a change here. A move to another control conversation would itself be your decision.

## Review packet

| Document | What you are reviewing |
|---|---|
| [New template design](TEMPLATE-DESIGN.md) | Independent identity, reusable structure and four proposed AI personas |
| [Persona heritage notes](PERSONA-HERITAGE-NOTES.md) | Approved heritage parallels and inherited instincts for all four personas, with sources |
| [Template assessment](TEMPLATE-ASSESSMENT.md) | What to retain, change and leave behind; source limitations |
| [Team charter](TEAM-CHARTER.md) | Purpose, authority, team structure and membership |
| [Role descriptions](ROLE-DESCRIPTIONS.md) | Founder, four proposed AI personas across seven responsibilities, and future Editor/contributor profiles |
| [Working agreement](WORKING-AGREEMENT.md) | How we collaborate, review, credit work and preserve decisions |
| [Gates and delivery](GATES-AND-DELIVERY.md) | Content and software workflows, human approvals and release evidence |
| [Records and adoption plan](RECORDS-AND-ADOPTION.md) | Work/approval templates, historical record and exact proposed adoption steps |

The diagram in the gates document covers the whole loop. Disha, Anvesha, Samanta and Drishti are approved names. The technology persona’s full name is Samanta Chandrasekhar; everyday name: Samanta. Names and the heritage parallels are approved; they do not activate personas or approve the full JDs. No persona or human has been onboarded by this package, and no independent agent review is claimed.

## Decisions for your review

Your title **Founder & Editor-in-Chief**, sole final authority, status as the **only human for now**, future human appointments as **Editors**, distinct template/persona identities and review before application are settled directions, not questions to reopen. The detailed design choices below remain proposals except the template name, subsequently selected as **Utkal Blueprint**:

| ID | Proposed choice | Effect if you approve it |
|---|---|---|
| UTP-GOV-001 | Adopt this charter and working agreement, with you as Founder & Editor-in-Chief | Establish one local operating model; explicit human authority |
| UTP-GOV-002 | Scope approval followed by approval of the result; combine for a fully prepared bounded batch | Work can proceed inside clear boundaries while application/publication remains yours |
| UTP-GOV-003 | Disha, Anvesha, Samanta and Drishti: all names approved; role grouping and JDs still proposed | Cover seven responsibilities with a small team; no personas activated |
| UTP-GOV-004 | Realize the four personas initially through declared role passes in this conversation | Separate role briefs from actual agent activation; be honest about review independence |
| UTP-GOV-005 | Keep future Editor onboarding ready but inactive, with a personal JD and explicit access | Add human Editors only when you decide they are needed |
| UTP-GOV-006 | Keep decisions here and preserve a versioned work/approval record in the project | Support continuity without treating an AI-written approval field as authorization |
| UTP-GOV-007 | Name the template **Utkal Blueprint** | Founder-selected name supersedes the earlier Living Knowledge Studio proposal; broader operating design still requires review |

**Possible review instruction:** “Approve UTP-GOV-001–UTP-GOV-007 for documentation adoption only, using proposal v0.1; prepare the exact OKF and PRD changes for my final review.” This is an example, not an approval record. You can approve individual items or revise any part. Approving the model does not by itself approve infrastructure, billing, outreach, memberships or deployment.

## Current status

- Template read and analyzed; selected source files fingerprinted in [the reference manifest](REFERENCE-MANIFEST.json).
- Proposal written locally; no template initializer, hooks, tests, propagation scripts or pipeline executed.
- Existing OKF, PRD baseline, source template and website configuration left unchanged.
- No Git repository created, permissions granted, messages sent, personas launched or services enabled.

This is a document review, not a claim that the proposed approval controls are implemented.
