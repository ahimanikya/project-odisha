# Hospitality alliance — planning sub-project

**Hospitality programme within the Utkal Collective direction · v0.2 · Planning only**

The Founder’s naming and scope discussion has progressed to [Utkal Collective](../utkal-collective/README.md), also intended to include future farm resorts and Bhubaneswar Athletic Club (BAC). This folder retains the hospitality membership plan; its earlier working name was Utkal Hospitality Alliance. The existing PRD is the preserved hospitality-only draft and does not cover BAC or property development.

An independent hospitality alliance, closely associated with Utkal Project, helping Odisha’s independent properties improve guest experiences and reach more business. Its separate planning space is created here at the Founder’s request. This is a folder-based sub-project, not a newly incorporated organisation, registered app project, live membership service or deployed website.

## Direction already given

- Develop our own model, with Secret Retreats as the principal reference and selected lessons from other alliances.
- Remain independent but closely associated with Utkal Project.
- Offer free membership initially, with clear disclosure that membership will become paid later as business is directed to members.
- Improve quality and visibility to create opportunities in Odisha.
- Keep plans reviewable here. Detailed implementation and external commitments require the Founder’s approval.

## The proposed model

**Join free → improve readiness → earn visibility → receive and track business → move to agreed paid membership.**

The promise is a practical path to better hospitality and business opportunity. A member retains ownership, identity and control over its prices. Membership, quality qualification and commercial billing are distinct states. Free membership is a founding phase, not a lifetime entitlement. Paid membership cannot purchase a favourable quality finding or encyclopedia coverage.

## Documents

| Document | Purpose |
|---|---|
| [Our operating model](MODEL.md) | Who we serve, services, independence, economics and responsibilities |
| [Membership and paid transition](MEMBERSHIP.md) | Founding offer, disclosure, evidence before charging and exit choices |
| [Quality and referrals](QUALITY-AND-REFERRALS.md) | Original quality framework, human assessment and business attribution |
| [PRD v0.1.0](PRD.md) | Scope, phased requirements, acceptance criteria, metrics and decisions |
| [Lessons from other models](LEARNING-NOTES.md) | Source-linked research and what we would adapt or defer |
| [Decisions and history](DECISIONS.md) | User-directed choices versus proposed details; preserved baseline |

## Review next

The recommended pilot is 5–10 willing properties within a manageable area, initially using reviewed profiles and manually coordinated enquiries. The size is proposed. No owners have been contacted or enrolled.

The principal choices for review are the pilot service promise, quality requirements, evidence needed before charging, the proposed 60-day notice period and the future fee structure. No prices, commissions, start date or guaranteed booking volume are approved.

Start with these documents before creating a repository, website, member intake or outreach campaign. The existing encyclopedia PRD, cloud services and billing remain unchanged. See [the wider purpose](../../UTKAL-PROJECT-PURPOSE.md) and [earlier alliance research](../../research/HOSPITALITY-ALLIANCE-RESEARCH.md).
