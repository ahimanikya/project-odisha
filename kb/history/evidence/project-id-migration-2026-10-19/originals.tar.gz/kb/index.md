---
okf_version: "0.2"
---

# Project Odisha · project knowledge bundle

**Discover Odisha. Imagine the possibilities.** UTP is an instance of Utkal Blueprint. This KB holds its actual project information and the knowledge behind its work.

This directory contains the organizational and working model, roles, work records, evidence and knowledge. Raw historical snapshots under `references/pre-repair/`, captured evidence under `history/evidence/initial-capture/`, and preserved earlier research snapshots under `records/evidence/research-import/` are archival resources, not live concepts. Executable tools and website code are outside this bundle; their operating context is documented here. External citations and explicitly linked independent repositories remain external resources.

[Whole-project concept catalogue](catalog.json) is generated from the live documents; preserved raw archives are excluded.

## Start here

- [Project identity](reference/project-identity.md)
- [Charter](TEAM-CHARTER.md)
- [Working agreement](Working-Agreement.md)
- [Team](team/index.md)
- [Repair status and preservation](reference/repair-status.md)

- [Current work and decisions](registers/DASHBOARD.md)
- [Knowledge-to-work programme](specs/knowledge-to-work.md)
- [Complete research collection](research/index.md)
- [Product requirements and versions](research/product/index.md)
- [Technical architecture](research/technology/index.md)
- [Project evolution](history/LEDGER.md)

- [Current article editorial standard](reference/article-editorial-standard.md) and [sequential work list](records/article-editorial-work-list.md).

## Current delivery and open work

Use these maintained records to resume work. The dated links further down this page preserve the project's evolution; an old “pending” or “disabled” note describes that snapshot, not necessarily the current state.

| What you need | Authoritative starting point |
| --- | --- |
| Current work, blockers, decisions and handovers | [Generated register dashboard](registers/DASHBOARD.md), backed by [canonical registers](registers/records.json) and [append-only activity](registers/activity.jsonl) |
| Progress on the Founder-authorized next 500 items | [Programme](records/autonomous-500-program.json): each completed item links its review and delivery evidence; the total is derived from completed entries |
| What was actually published or applied | [Publication and application history](registers/DASHBOARD.md#publication-and-application-history), followed by the release's evidence in [canonical registers](registers/records.json); [how to read those records](records/index.md) |
| What still needs editorial, language, accessibility or local review | [Consolidated visitor-review queue](records/visitor-review-queue.json) and each referenced work item's current status; publication does not close those wider gaps |
| Fieldwork waiting on human decisions or local confirmation | [Founder TODO](specs/founder-todo.md) and [fieldwork pack](specs/tourism-fieldwork/index.md); no introductions, host consent or service inspection should be inferred |
| Research to reuse before starting a new topic | [Research map](research/methods/research-map.md) and [research index](research/index.md) |

**Search status, checked against saved evidence on 9 October 2026:** limited search eligibility was activated for eleven routes under UTP-DEC-150; see the [activation receipt](records/first-search-launch-publication.json). The [9 October maritime publication receipt](records/maritime-memory-publication-2026-10-09.json) confirms the same eleven-entry sitemap and keeps that new story outside the search selection. This is not proof that Google has indexed those pages. [Search Console processing remains unresolved in the saved diagnosis](records/search-console-fetch-diagnosis.json), tracked as UTP-WORK-139. Consult later release receipts and the current register before relying on this dated snapshot.

The public preview, the full research KB and the approved search selection have different scopes. Utkal Store remains held; its separate workspace is not a published shop. Human authority remains with Ahimanikya Satapathy; an automated check or a delivery receipt is not independent factual or field review.

## Groups

- [history](history/index.md)
- [records](records/index.md)
- [reference](reference/index.md)
- [references](references/index.md)
- [registers](registers/index.md)
- [research](research/index.md)
- [specs](specs/index.md)
- [team](team/index.md)

- [Repository boundaries and proposed code layout](reference/repository-layout.md)

- [Website and brand foundation](specs/website-brand-foundation.md)

- [Current brand direction](reference/brand-direction-02.md)
- [Odisha sensory identity research](reference/odisha-sensory-identity.md)
- [Utkal Store placement and scope](specs/utkal-store.md)
- [Photo and cultural collections](collections/index.md)

- [Vector identity and merchandise design](reference/brand-vector-03.md)

- [First collection editorial review](reference/first-collection-editorial-review.md)

- [The Utkal way of telling a story](reference/storytelling-standard.md)

- [Destination model and tourism benchmarks](reference/destination-model.md)
- [Personal tour-book requirements](research/product/destination-and-tour-book.md)

- [Utkal Knowledge & Story Model](reference/knowledge-story-model.md)
- [Content models and research templates](models/index.md)

- [Five travel websites: lessons and proposed information architecture](reference/travel-website-benchmark.md)

- [Culture-first travel direction and pilot sequence](research/product/culture-first-travel-direction.md)

- [Chilika and Konark destination pilots](reference/destination-pilots-review.md)

- [Connected destinations and immersive preview](research/product/immersive-destination-brief.md)

- [Languages and Living Voices](reference/language-heritage-model.md) — Odia-first language histories, cultural connections and research queue.

- [Odia Literature & Literary Lives](research/culture/odia-literature-and-literary-lives.md) — writers, works, history and place connections.

- [Language and literature website pilot](research/voices/index.md) — six connected pages, canonical content and image provenance.

- [My Odisha Journey and cultural reading trails](research/product/culture-journey-prototype.md) — personal planning prototype and review evidence.

- [Utkal Design System](design-system/index.md) — reusable library, component gallery, three page pilots and adoption guidance.

- [Current coastal launch-readiness review](research/product/launch-readiness-2026-09-30.md)

- [Coastal preview publication · 30 September 2026](research/product/coastal-publication-2026-09-30.md)

- [Launch-quality follow-up · delivery, guide evidence and print](research/product/launch-quality-2026-09-30.md)

- [Visitor readiness: guides, Chrome PDF checks, analytics and consolidated review](research/product/visitor-readiness-2026-10-01.md)

- [Chilika release candidate](records/chilika-release-review.json) — connected guides, three journey starters, source checks and review evidence.

- [Cuttack collection review and publication](records/cuttack-release-review.json) — fort, craft, food, museum and a connected journey.
- [Odia language and literature review and publication](records/odia-literature-release-review.json) — six literary lives and portable reading notes.

- [Northern collection review and publication](records/northern-release-review.json) — Balasore, Mayurbhanj, food, two bases and portable journey books.

- [Planning hubs review and publication](records/planning-hubs-review.json) — destination, food, experience and stay-area discovery with connected journey navigation.

- [Languages and Living Voices candidate](research/product/living-languages.md) — seven introductions, original learning publications and speaker contribution proposals.

Latest language release: [Languages and Living Voices publication](records/living-languages-publication.json) — approved PR 20, seven introductions live; specialist review remains open.

- [Expanded research import](records/research-sync-2026-10-01.md) — broader subjects, people, creations and dated economic evidence; research-only review candidate.


- [Research map and reuse](research/methods/research-map.md) — cross-workspace coverage, checked overlaps and evidence pointers for all research tasks.
- [Visitor experience and search readiness](reference/visitor-experience-review.md) — navigation, sharing previews, complete journey checks and one remaining human review queue.

Historical visitor-experience release: [PR 23 publication evidence](records/visitor-experience-publication.json). Search indexing was disabled for that release; later limited activation is described in the current delivery guide above.

- [Odisha Roots stories and publication](records/odisha-roots-features-publication.json) — illustrated Rasagola and Bose stories, portable notes and source limits.

- [Research map and reuse](research/methods/research-map.md) — cross-workspace coverage, checked overlaps and evidence pointers for all research tasks.

- [Editorial workbench](reference/editorial-workbench.md) — 500 traceable metadata assessments and the next illustrated food stories.

- [Cultural reading-flow review](records/culture-flow-review.json) — six-page responsive review and maker-cover refinements; [published as UTP-REL-048](records/culture-flow-publication.json).

- [Global Connections: section and future initiative](specs/global-connections.md)

- [Tourism experience pilot](specs/tourism-experience-pilot.md) — actionable plan, evidence gaps, local-confirmation template and tracked work.

[Tourism pilot desk research](research/collections/tourism-pilot-desk-review.md) — official evidence, experience shortlist and costed capacity options.

- [Six experience fieldwork pack](specs/tourism-fieldwork/index.md) — coordinator brief, visit questions, unsent introductions and cost tracker.
- [Operator readiness and trial decision pack](specs/tourism-fieldwork/operator-readiness.md) — assessment states, six-lead gap map and a reusable trial proposal; no field confirmation implied.

- [Founder TODO](specs/founder-todo.md) — deferred field-pilot decisions.
- [Six stories to read before a visit](research/stories/narratives/tourism-reading-collection.md) — museum, inscription and craft article drafts.

- [Tourism opportunities section requirements](specs/tourism-opportunities-section.md) — official guidance, cultural reading and contribution flows, with operating dependencies kept explicit.

- [Maritime memory: a small boat, a wider world](research/stories/narratives/maritime-memory.json) — illustrated public narrative connecting ritual, anchor provenance, India–Bali research and questions for a museum visit.

- [Boita tourism discussion framework](specs/boita-tourism-discussion-framework.md) — desk proposal connecting public-service improvements and local entrepreneurship; field findings and external engagement remain separate.

- [Konark and Mamallapuram heritage learning proposal](specs/konark-mamallapuram-learning-proposal.md) — a sourced candidate for reciprocal visitor storytelling, with local interest and activity decisions still open.

## Sounds of Odisha: research and published reading

The [maintained collection directory](research/culture/sounds-of-odisha.md#what-is-published) links **22 published full stories**, their KB narratives, website text and release receipts, checked against saved delivery evidence on 15 October 2026 (UTC). Eight core chapters and fourteen further readings are distinct; the collection and listening notebook are additional pages.

- [Read Sounds of Odisha](https://projectodisha.org/sounds-of-odisha/) or use the [listening notebook](https://projectodisha.org/sounds-of-odisha/listening-notebook/).
- [Huluhuli research](research/culture/huluhuli.md) and [source dossier](research/sources/huluhuli-research.md) retain origin limits; the [tongue-motion correction receipt](records/huluhuli-tongue-correction-publication-2026-10-12.json) records the Founder's correction.
- [Boat songs](research/culture/boat-songs.md) is published as further reading, with [delivery evidence](records/boat-songs-publication-2026-10-15.json).
- [Source notes across the eight core stories](records/core-sound-sources-publication-2026-10-15.json) provide passage-to-evidence navigation. [Discovery](research/product/sounds-discovery.json) and [thematic reading paths](research/product/sounds-reading-paths.json) connect all published sound stories.
- [Recording model](models/sound-recording.md) and [listening briefs](records/sound-recording-briefs.json) describe preparation; no audio archive or confirmed performance booking is implied.

Use the directory's [unfinished evidence questions](research/culture/sounds-of-odisha.md#what-remains-unfinished) for follow-up. Publication does not close practitioner/language review, source-access limits or local confirmation. Historical receipts and original research remain intact; later delivery state belongs to the current registers.
